package com.cpagemini.employeewebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.employeeweapp.beans.EmployeeInfoBean;
import com.capgemini.employeewebapp.dao.EmployeeDAO;
import com.capgemini.employeewebapp.dao.EmployeeDAOJpaImpl;
@WebServlet("/searchEmployee")
public class SearchEmployeeServlet  extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	String empIdValue	=req.getParameter("empId");
		
		int empId=Integer.parseInt(empIdValue);
		
		EmployeeDAO dao=new EmployeeDAOJpaImpl();
		EmployeeInfoBean employeeInfoBean=dao.getEmployee(empId);
		
		resp.setContentType("text/html");
		PrintWriter out=resp.getWriter();
		
		
		out.println("<html>");
		out.println("<body>");
		
		
		if(employeeInfoBean!=null)
		{
			out.println("<h2>Employee ID ="+empId +"Found-</h2>");
			out.println("<h4>Employee Name=" +employeeInfoBean.getEmpName());
			out.println("<br>Employee Age=" +employeeInfoBean.getAge());
			out.println("<br>Employee Mobile=" +employeeInfoBean.getMobile());
			out.println("<br>Employee Gender=" +employeeInfoBean.getGender());
			out.println("<br>Employee Salary=" +employeeInfoBean.getSalary());
			out.println("<br>Employee Desgination=" +employeeInfoBean.getDesignation());
			out.println("<br>Employee Name=" +employeeInfoBean.getEmpName());
			out.println("<br>Password=" +employeeInfoBean.getPassword()+"</h4>");
			
		}
		
		else
		{
			
			out.println("<h3 style='color:red>Emplyee Id"+empId +"NotFound");
			
		}
		
		
		out.println("</html>");
		out.println("</body>");
		
	}
	
	
}
