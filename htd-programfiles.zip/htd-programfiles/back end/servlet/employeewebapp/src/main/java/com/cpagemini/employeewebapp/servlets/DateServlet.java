package com.cpagemini.employeewebapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DateServlet extends HttpServlet{
  
	public DateServlet()
	{
		System.out.println("Its Instaniantion phase");
		
	}
	
	@Override
	public void init() throws ServletException {
		System.out.println("Its Init phase......");

	}
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Its Service phase.....");
		
		
		Date date=new Date();
		//resp.setHeader("refresh", "1");
		resp.setContentType("text/html");
		ServletContext context=getServletContext();
		String abc=context.getInitParameter("companyName");
		PrintWriter out=resp.getWriter();
		out.println("<html>");
//		out.println("<head>");
//		out.println("<meta http-equiv='refresh' content='1'>");
//		out.println("</head>");
		out.println("<body>");
		out.println("<h1>Current System Date & time-<br>");
		
		out.println(date+ "</h1>");
		out.println("<h1>Name of company is :" +abc +"</h1>");
		out.println("</body>");
		out.println("</html>");
	}//end of doGet
	@Override
	public void destroy() {
		System.out.println("Destroy Phase");
		
	}
	
}
//end of the class