package com.capgemini.japwithhibernate.onetoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;




public class TestOnetoOne {

	public static void main(String[] args) {
		EntityManager entityManager=null;
		EntityTransaction transaction=null;

		Person person=new Person();
		
		person.setPid(2);
		person.setName("shital");
	
		VoterCard vc = new VoterCard();
		
		vc.setVid(12356);
		vc.setAddress("NERLE");
		person.setVotercard(vc);
			
		
		try {
			System.out.println("....");
			EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("test");
		 entityManager=entityManagerFactory.createEntityManager();
			 transaction=entityManager.getTransaction();
			
			transaction.begin();
			entityManager.persist(person);
		/*	System.out.println(person.getName());
			System.out.println(person.getPid());
			System.out.println(vc.getVid());
			System.out.println(vc.getAddress());*/
//			VoterCard details=entityManager.find(VoterCard.class, 1235);
//			System.out.println(details.getVid());
//		System.out.println(details.getAddress());
//		System.out.println(details.getPerson().getPid());
//		System.out.println(details.getPerson().getName());
//			
			System.out.println("Record saved");
			transaction.commit();
			
		} 
		catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
		entityManager.close();
		
	}


	}


