package com.capgemini.jpawithhibernate.manytomany;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestManytomany {

	public static void main(String[] args) {
		EntityManager entityManager=null;
		EntityTransaction transaction=null;
		/*Student s=new Student();
		s.setSid(10);
		s.setSname("shital");
		*/
		Course c=new Course();
		
		c.setCid(101);
		c.setCname("Maths");
		Course c1=new Course();
		c1.setCid(11);
		c1.setCname("SQL");
		
		ArrayList<Course> alist=new ArrayList<Course>();
		alist.add(c);
		alist.add(c1);
		
		
		Student s1=new Student();
		s1.setSid(1);
		s1.setSname("komal");
		s1.setCourse(alist);
		
		
		
		try
		{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("test");
		 entityManager=entityManagerFactory.createEntityManager();
			 transaction=entityManager.getTransaction();
			
			transaction.begin();
			entityManager.persist(s1);
		
		
			System.out.println("Record saved");
			transaction.commit();
		}
	catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
		entityManager.close();
		


	}

}
