package com.capgemini.jpawithhibernate.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.jpawithhibernate.dto.Movie;

public class Retrival {

	public static void main(String[] args) {
		
		Movie movie=new Movie();
		   EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("test");
		   EntityManager entityManager=entityManagerFactory.createEntityManager();
		    Movie data=entityManager.find(Movie.class, 1);
		    
		    String jpql="from Movie";
		    Query query=entityManager.createQuery(jpql);
		    
		    List<Movie> list=query.getResultList();
		    
		    for(Movie m:list)
		    {
		   /* System.out.println("ID IS: "+data.getId());
		    System.out.println("NAME IS: "+data.getName());
		    System.out.println("RATING IS: "+data.getRating());*/
		    	
		    	System.out.println(m.getId());
		    	System.out.println(m.getName());
		    	System.out.println(m.getRating());
		    }


	}

}
