package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Delete {

	public static void main(String[] args) {
		
		EntityTransaction transaction=null;
		   EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("test");
		   EntityManager entityManager=entityManagerFactory.createEntityManager();
		   transaction=entityManager.getTransaction();

		    String jpql="delete from Movie where id=2";
		    transaction.begin();
		    Query query=entityManager.createQuery(jpql);
		    int result=query.executeUpdate();
		 	
        System.out.println("result:"+result);
		    System.out.println("record is deleted");
		    transaction.commit();
		  



	}

}
