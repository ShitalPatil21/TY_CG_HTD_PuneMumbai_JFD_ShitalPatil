package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class DynamicDelete {

	public static void main(String[] args) {

		EntityTransaction transaction=null;
		   EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("test");
		   EntityManager entityManager=entityManagerFactory.createEntityManager();
		   transaction=entityManager.getTransaction();

		    String jpql="delete from Movie where id=:mid";
		    transaction.begin();
		    Query query=entityManager.createQuery(jpql);
		    
		    //query.setParameter("nm", "AVTAR");
		    query.setParameter("mid",2);
		    
		    int result=query.executeUpdate();
		 	
        System.out.println("result:"+result);
		    System.out.println("record is deleted");
		    transaction.commit();


	}

}
