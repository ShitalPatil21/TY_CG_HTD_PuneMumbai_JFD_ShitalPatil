package com.capgemini.jpawithhibernate.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Testonetomany {

	public static void main(String[] args) {
		EntityManager entityManager=null;
		EntityTransaction transaction=null;
		PencilBox pensilbox =new PencilBox();
		pensilbox.setBoxid(7);
		pensilbox.setName("Camlin");
		
		
		
		
		Pencil pencil =new Pencil();
		pencil.setId(1);
		pencil.setColor("Black");
		pencil.setPensilbox(pensilbox);
		
		Pencil pencil1 =new Pencil();
		pencil1.setId(2);
		pencil1.setColor("REd");
		pencil1.setPensilbox(pensilbox);
	
		
		
		
		try
		{
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("test");
		 entityManager=entityManagerFactory.createEntityManager();
			 transaction=entityManager.getTransaction();
			
			transaction.begin();
			entityManager.persist(pencil);
			entityManager.persist(pencil1);
			
		
		
			System.out.println("Record saved");
			transaction.commit();
		}
	catch (Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}
		entityManager.close();
		
		
		
		
		


	}

}
