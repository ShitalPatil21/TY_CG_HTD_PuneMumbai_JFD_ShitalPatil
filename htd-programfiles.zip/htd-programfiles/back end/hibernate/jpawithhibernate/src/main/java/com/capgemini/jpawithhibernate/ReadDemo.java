package com.capgemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.dto.Movie;

public class ReadDemo {

	public static void main(String[] args) {
   Movie movie=new Movie();
   EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("test");
   EntityManager entityManager=entityManagerFactory.createEntityManager();
    Movie data=entityManager.find(Movie.class, 1);
    
    System.out.println("ID IS: "+data.getId());
    System.out.println("NAME IS: "+data.getName());
    System.out.println("RATING IS: "+data.getRating());
    


	}

}
