package com.capg.school.school_implementation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.Set;

import com.capg.school.school_info.school_info;
import com.capg.school_interface.school_interface;



public class school_implementaion  implements school_interface{
	Connection conn = null;
	Statement stmt =null;
	ResultSet rs = null;
	PreparedStatement pstmt =null;
	Scanner sc = new Scanner(System.in);
	public school_implementaion () {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("load the Driver");
			System.out.println("..................................................");
			String dburl = "jdbc:mysql://localhost:3306/school_db?user=root&password=root";
			conn  = DriverManager.getConnection(dburl);
			System.out.println("Get the connection");
			System.out.println("....................................................");
		} //end of try
		catch (Exception e) {
			e.printStackTrace();
		}//end of catch
		
	}//end of constructor

	@Override
	public school_info getAllInfo() {
		
		System.out.println("its get all info method");
		
		
		try {
			String query ="select * from school";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			
			while(rs.next()) {
				System.out.println("school id  =  "+rs.getInt(1));
				System.out.println("school name  = "+rs.getString(2));
			}
			
		}//end of try 
		catch (Exception e) {
			e.printStackTrace();
		}//end of catch
		
		return null;
	}//end of getAllInfo method

	@Override
	public school_info insertData(int school_id,String school_name) {
		
		
		try {
			String query = "insert into school values(?,?)";
						
			pstmt = conn.prepareStatement(query);
			pstmt.setInt(1,school_id);
			pstmt.setString(2, school_name);
			int count = pstmt.executeUpdate();
			
			if(count>0) {
				System.out.println("data inserted");
			}
			else {
				System.out.println("data is not inserted...something went wrong");
			}
			
		}//end of try
		catch (Exception e) {
			e.printStackTrace();
		}//end of catch
		return null;
	}//end of insertData method

	@Override
	public school_info updateData(int school_id,String school_name) {
		
		try {
			String query = "update school set school_name = ? where school_id = ?";
			pstmt = conn.prepareStatement(query);
			pstmt.setString(1, school_name);
			pstmt.setInt(2, school_id);
			
			int count = pstmt.executeUpdate();
			
			if(count>0) {
				System.out.println("data updated");
			}
			else {
				System.out.println("data is not updated...something went wrong");
			}
		} //end of try
		catch (Exception e) {
			e.printStackTrace();
		}//end of catch
		
		return null;
	}//end of updatedata method

	@Override
	public school_info deleteData(int school_id) {
		
		
		try {
			String querey="delete from school where school_id = ?";
			pstmt = conn.prepareStatement(querey);
			pstmt.setInt(1, school_id);
			int count = pstmt.executeUpdate();
			if(count>0)
			{
				System.out.println("data deleted");
			}
			else
			{
				System.out.println("data is not deleteds...something went wrong");
			}
		}//end of try
		catch (Exception e) {
			e.printStackTrace();
		}//end of catch
		
		return null;
	}//end of deleteData method

	@Override
	public school_info apply(int count,int school_id) {
		for(int i =1;i<=count;i++) {
			
			try {
				String query="select school_id , school_name from school where school_id = ?";
				pstmt = conn.prepareStatement(query);
				System.out.println("...............................................");
				System.out.println("enter school ID");
				pstmt.setInt(1, Integer.parseInt(sc.nextLine()));
				rs = pstmt.executeQuery();
				if(rs.next())
				{
					System.out.println("ID = "+rs.getInt(1));
					System.out.println("name = "+rs.getString(2));
				}
				
			}//end of try 
			catch (SQLException e) {
				e.printStackTrace();
			}//end of catch
			
		}//end of for loop
		
		return null;
	}//end of apply method
	

}//end of school_implementaion class
