package com.capg.school_interface;

import com.capg.school.school_info.school_info;

public interface school_interface {
	
	public school_info getAllInfo();
	
	public school_info insertData(int school_id,String school_name);
	
	public school_info updateData(int school_id,String school_name);
	
	public school_info deleteData(int school_id);
	
	public school_info apply(int count,int school_id);

}//end of interface
