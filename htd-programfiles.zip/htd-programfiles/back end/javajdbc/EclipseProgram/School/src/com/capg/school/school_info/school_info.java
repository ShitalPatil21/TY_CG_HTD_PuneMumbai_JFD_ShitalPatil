package com.capg.school.school_info;

public class school_info {
	
	private int sch_id;
	private String sch_name;
	
	//getter and setter method
	public int getSch_id() {
		return sch_id;
	}
	public void setSch_id(int sch_id) {
		this.sch_id = sch_id;
	}
	public String getSch_name() {
		return sch_name;
	}
	public void setSch_name(String sch_name) {
		this.sch_name = sch_name;
	}
	
	

}//end of class
