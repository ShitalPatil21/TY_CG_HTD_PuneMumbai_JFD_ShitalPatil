package com.capg.school.school_factoy;

import com.capg.school.school_implementation.school_implementaion;
import com.capg.school_interface.school_interface;

public class school_factory {
	
	private school_factory() {
		
	}//end of constructor
	
	public static school_interface getInstance() {
		school_interface siobj = new school_implementaion();
		return siobj;
	}//end of getInstance method

}//end of school_factory class
