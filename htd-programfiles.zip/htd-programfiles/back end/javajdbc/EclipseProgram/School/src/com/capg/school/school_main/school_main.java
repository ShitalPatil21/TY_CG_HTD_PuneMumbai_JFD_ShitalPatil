package com.capg.school.school_main;

import java.util.Scanner;

import com.capg.school.school_factoy.school_factory;
import com.capg.school_interface.school_interface;

public class school_main {
	
	public static void display(school_interface siobj) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Press 1 to get all info ");
		System.out.println("press 2 to insert data");
		System.out.println("press 3 to update data");
		System.out.println("press 4 to delte data");
		System.out.println("press 5 to apply");
		int button = Integer.parseInt(sc.nextLine());
		if(button == 1) {
		siobj.getAllInfo();
		}//end of button = 1
		else 
			if(button == 2) {
				
				System.out.println("Enter school ID");
				int school_id = Integer.parseInt(sc.nextLine());
				System.out.println("Enter school name");
				String school_name = sc.nextLine();
				siobj.insertData(school_id, school_name);
			}//end of button = 2
			
		else
			if(button == 3) {
				System.out.println("Enter school ID where you want to update");
				int school_id = Integer.parseInt(sc.nextLine());
				System.out.println("Enter the name ");
				String school_name = sc.nextLine();
				siobj.updateData(school_id,school_name);
			}//end of button = 3
			else
				if(button == 4) {
					System.out.println("Enter the school ID where you want to delete");
					int school_id =Integer.parseInt(sc.nextLine());
					siobj.deleteData(school_id);
				}//end of buttton = 4
				else
					if(button ==5) {
						System.out.println("enter how many school you want to apply");
						int count = Integer.parseInt(sc.nextLine());
						int school_id=0;
						siobj.apply(count, school_id);
					}
			else {
				System.out.println("you entered wrong number");
			}//end of if else
		System.out.println("...............................................");
		System.out.println("Enter 'YES' to continue and 'NO' to exit");
		String a = sc.nextLine();
		if(a.equals("yes"))
		{
			display(siobj);
		}
		else
			if(a.equals("no"))
		{
				System.out.println("Exit");
			return;
		}
	}//end of display method

	public static void main(String[] args) {
		
		school_interface siobj = school_factory.getInstance();
		display(siobj);
		
	}//end of main method

}//end of school_main class
