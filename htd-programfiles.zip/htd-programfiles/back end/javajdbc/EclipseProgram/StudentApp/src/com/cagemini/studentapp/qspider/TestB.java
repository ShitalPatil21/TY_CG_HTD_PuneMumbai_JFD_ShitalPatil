package com.cagemini.studentapp.qspider;

import com.cagemini.studentapp.jspider.*;		// * =  import all files //it only import the classes and interface

public class TestB {
	public static void main(String [] args)
	{
		selenium se=new selenium();
		se.techSelenium();

		QTP qtp=new QTP();
		qtp.techQTP();

		react re=new react ();
		re.teachReact();

		angular an= new angular();
		an.teachAngular();
	}

}
