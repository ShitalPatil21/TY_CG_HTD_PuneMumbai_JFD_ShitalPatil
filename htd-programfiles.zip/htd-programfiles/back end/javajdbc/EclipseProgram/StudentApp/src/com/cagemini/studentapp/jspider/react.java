package com.cagemini.studentapp.jspider;

public class react {

	public void teachReact() {
		System.out.println("I am teach React mathod");
	}

}
