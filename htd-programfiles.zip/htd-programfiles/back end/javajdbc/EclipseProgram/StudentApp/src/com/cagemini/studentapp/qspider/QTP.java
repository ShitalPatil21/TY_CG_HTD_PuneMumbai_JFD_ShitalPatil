package com.cagemini.studentapp.qspider;

public class QTP {
	public void techQTP() {
		System.out.println("I am teach QTP mathod");
	}
	
}
