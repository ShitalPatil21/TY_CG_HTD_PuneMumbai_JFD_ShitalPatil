package com.cagemini.studentapp.qspider;

import com.cagemini.studentapp.jspider.angular;
import com.cagemini.studentapp.jspider.react;

public class TestA {
	
	public static void main(String [] args)
	{
		selenium se=new selenium();
		se.techSelenium();
		
		QTP qtp=new QTP();
		qtp.techQTP();
		
	react re=new react ();
	re.teachReact();
	
	angular an= new angular();
	an.teachAngular();
	}

}
