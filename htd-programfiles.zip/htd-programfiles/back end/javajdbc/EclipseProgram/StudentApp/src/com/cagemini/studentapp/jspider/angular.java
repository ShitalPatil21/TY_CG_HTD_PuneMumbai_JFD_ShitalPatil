package com.cagemini.studentapp.jspider;

public class angular {

	public void teachAngular() {
		System.out.println("I am teach angular mathod");
	}

}
