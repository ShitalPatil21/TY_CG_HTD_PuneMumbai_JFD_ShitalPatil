package com.cagemini.studentapp.qspider;

import com.cagemini.studentapp.jspider.*;

import static com.cagemini.studentapp.jspider.remote.*;
public class TestC {
	
	public static void main(String [] args)
	{
		on();
		System.out.println("static int a value = "+a);
		
		
		remote obj=new remote();
		obj.off();
		System.out.println("non static int a value = "+obj.b);
		
	}
}