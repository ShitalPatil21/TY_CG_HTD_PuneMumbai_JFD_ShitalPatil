package com.cagemini.studentapp.jspider;

public class remote {
	
	public static int a=100;
	public int b=200;
	public static void on()
	{
		System.out.println("remote on method");
	}
	
	public  void off()
	{
		System.out.println("remote on method");
	}

}
