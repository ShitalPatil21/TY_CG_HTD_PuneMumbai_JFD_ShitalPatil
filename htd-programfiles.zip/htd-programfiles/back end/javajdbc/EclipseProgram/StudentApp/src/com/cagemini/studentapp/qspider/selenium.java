package com.cagemini.studentapp.qspider;

public class selenium {

	public void techSelenium() {
		System.out.println("I am teach selenium mathod");
	}

}
