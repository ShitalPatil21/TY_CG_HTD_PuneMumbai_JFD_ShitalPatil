package MethodOverloading;

public class Facebook {
	
	public void Login(String Email,String password)
	{
		System.out.println("facebook login from email"+Email+""+password);
	}

	public void Login(int number,String password)
	{
		System.out.println("facebook login from number"+number+""+password);
	}
}
