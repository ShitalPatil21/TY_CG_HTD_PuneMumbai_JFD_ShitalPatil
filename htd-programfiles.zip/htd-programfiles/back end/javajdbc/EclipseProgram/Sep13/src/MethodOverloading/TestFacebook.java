package MethodOverloading;

public class TestFacebook {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Facebook fb=new Facebook();
		fb.Login(451244522,"abc");
		fb.Login("aishu@gmail.com","abc");

	}

}
