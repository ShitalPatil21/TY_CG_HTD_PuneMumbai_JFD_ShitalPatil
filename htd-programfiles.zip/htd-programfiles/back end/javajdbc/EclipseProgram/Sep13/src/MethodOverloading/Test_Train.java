package MethodOverloading;

public class Test_Train {
	
	public static void main(String [] args)
	{
		Train t=new Train();
		t.Search(10);
		t.Search("Mumbai");
	}

}
