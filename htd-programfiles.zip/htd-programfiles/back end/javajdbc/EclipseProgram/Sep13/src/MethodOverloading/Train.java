package MethodOverloading;

public class Train {
	
	
	public void Search(String name)
	{
		System.out.println("Train search by Name  = "+name);
	}
	
	public void Search(int number)
	{
		System.out.println("Train search by Number = "+number);
	}

}
