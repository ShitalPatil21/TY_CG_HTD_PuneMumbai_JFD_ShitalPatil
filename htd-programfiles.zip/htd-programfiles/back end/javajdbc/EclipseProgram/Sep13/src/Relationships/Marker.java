package Relationships;

public class Marker {
	
	void write()
	{
		System.out.println("write method from marker");
	}
	 
	void color()
	{
		System.out.println("color method from marker");
	}

}
