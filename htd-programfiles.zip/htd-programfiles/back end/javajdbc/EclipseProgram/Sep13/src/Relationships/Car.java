package Relationships;

public class Car {
	
	MusicSystem ms=new MusicSystem();
	
	void carmusic()
	{
		System.out.println("music system is in car");
	}

}
