package Relationships;

public class Test {
	
	public static void main(String [] args) {
		
		Person p =new Person();
		System.out.println("int value from person"+p.a);
		p.walk();
		p.m.color();
		p.m.write();
	}
	

}
