package Relationships;

public class Fan {
	void on()
	{
		
		System.out.println("on method from fan class");
	}
	
	 void off()
	{
		System.out.println("off method from fan class");
	}

}
