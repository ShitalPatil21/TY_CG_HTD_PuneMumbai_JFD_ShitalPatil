package Relationships;

public class TestStaticHasRelation {
	
	public static void main(String []args)
	{
		
		Room.f.on();
		Room.f.off();
		Room.abc();
		System.out.println(Room.a);
	}

}
