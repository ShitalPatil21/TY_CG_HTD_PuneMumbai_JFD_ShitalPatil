package Relationships;

public class Room {
	static int a=100;
	static Fan f = new Fan();
	
	static void abc()
	{
		System.out.println("abc method from room class");
	}
	

}
