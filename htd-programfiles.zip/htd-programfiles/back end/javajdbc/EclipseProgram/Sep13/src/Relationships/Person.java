package Relationships;

public class Person {
	int a=100;
	Marker m = new Marker();
	void walk()
	{
		System.out.println("walk method from person");
	}
	
}
