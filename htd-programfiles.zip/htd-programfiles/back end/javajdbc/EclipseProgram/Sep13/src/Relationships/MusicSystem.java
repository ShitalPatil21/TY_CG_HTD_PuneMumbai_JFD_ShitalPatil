package Relationships;

public class MusicSystem {

	void DJ()
	{
		System.out.println("DJ music playing");
	}
}
