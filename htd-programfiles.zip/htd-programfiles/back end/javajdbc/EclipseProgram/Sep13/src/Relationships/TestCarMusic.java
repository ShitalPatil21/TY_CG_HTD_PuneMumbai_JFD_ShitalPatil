package Relationships;

public class TestCarMusic {

	public static void main(String []args)
	{
		Car c=new Car();
		c.ms.DJ();
		c.carmusic();
		
	}
}
