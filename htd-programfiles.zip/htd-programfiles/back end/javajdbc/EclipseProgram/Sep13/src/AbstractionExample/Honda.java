package AbstractionExample;

public class Honda extends Bike {

	@Override
	public void run1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void run2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void run3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	int run5() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	boolean run6() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	char run7() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	String run8() {
		// TODO Auto-generated method stub
		return null;
	}

		
	

}
