package AbstractionExample;

public class Testabstraction extends Check {
	
	void hello()
	{
		System.out.println("hello");
	}
	
	public static void main(String []args)
	{
		Check obj=new Testabstraction();
		obj.hello();
	}

}
