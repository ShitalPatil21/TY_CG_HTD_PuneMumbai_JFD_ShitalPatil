package AbstractionExample;

public abstract class  Bike
{
	
	// Access -specifier
	
	public abstract void run1();
	protected abstract void run2();
	abstract void run3();
	//private abstract void run4();
	
	
	
	//Any database we can use as return type in abstract method
	
	abstract int run5();
	abstract boolean run6();
	abstract char run7();
	abstract String run8();
	
	
	//final abstract void run9();
	
	public static void run9()
	{
		
	}
	
	protected static void run10()
	{
		
	}
	
	static void  run11()
	{
		
	}
	 
	static private void  run12()
		{
			
		}
	 
	
}