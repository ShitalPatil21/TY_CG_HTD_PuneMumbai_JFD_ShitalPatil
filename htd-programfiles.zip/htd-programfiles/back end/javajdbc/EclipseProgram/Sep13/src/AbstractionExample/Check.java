package AbstractionExample;

public abstract class Check {
	abstract void hello();
	
}
