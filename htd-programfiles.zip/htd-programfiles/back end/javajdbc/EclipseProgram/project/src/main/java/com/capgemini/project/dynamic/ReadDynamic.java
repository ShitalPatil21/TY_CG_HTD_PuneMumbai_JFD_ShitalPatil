package com.capgemini.project.dynamic;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.project.entitybean.empbean;

public class ReadDynamic {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("emp");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();

		String query1 = "from empbean where id=:id";
		Query q = em.createQuery(query1);
		System.out.println("enter id ");
		q.setParameter("id", Integer.parseInt(sc.nextLine()));
		List<empbean> list = q.getResultList();
		
		for (empbean m : list) {
			System.out.println(m.getId());
			System.out.println(m.getName());
			System.out.println(m.getSalary());
		}
		et.commit();
		sc.close();
		em.close();
	}

}
