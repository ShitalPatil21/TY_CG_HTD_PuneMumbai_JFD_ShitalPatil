package com.capgemini.project;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.project.entitybean.empbean;

public class UpdateEmp {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("emp");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et =em.getTransaction();
		
		et.begin();
		
		System.out.println("enter emp id where u want to update");
		empbean eb_obj = em.find(empbean.class, Integer.parseInt(sc.nextLine()));
		
		System.out.println("Enter 1 to update Emp Name");
		System.out.println("enter 2 to update salary");
		int a = Integer.parseInt(sc.nextLine());
		if(a==1)
		{
			System.out.println("enter Name to update");
			eb_obj.setName(sc.nextLine());
		}
		else
			if(a==2)
			{
				System.out.println("enter salary to update");
				eb_obj.setSalary(Double.parseDouble(sc.nextLine()));
			}
			else {
				System.out.println("enter valid no");
			}
		
		System.out.println("record updated");
		et.commit();
		sc.close();
	}

}
