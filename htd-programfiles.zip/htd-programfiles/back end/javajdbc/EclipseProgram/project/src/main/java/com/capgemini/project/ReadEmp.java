package com.capgemini.project;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.project.entitybean.empbean;

public class ReadEmp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("emp");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		et.begin();
		System.out.println("enter ID which you want to serach");
		empbean eb_obj = em.find(empbean.class,Integer.parseInt(sc.nextLine()));
	
		
		System.out.println("Employee ID = "+eb_obj.getId());
		System.out.println("Employee Name = "+eb_obj.getName());
		System.out.println("Employee Salary = "+eb_obj.getSalary());
		
		et.commit();
		em.close();
		sc.close();
		em.close();
	}

}
