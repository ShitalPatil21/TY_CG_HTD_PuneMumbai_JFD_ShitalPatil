package com.capgemini.project;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;


import com.capgemini.project.entitybean.empbean;

public class InsertEmp {
public static void main(String[] args) {
	
	Scanner sc = new Scanner(System.in);
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("emp");
	EntityManager em = emf.createEntityManager();
	EntityTransaction et = em.getTransaction();
	
	empbean eb_obj = new empbean();
	
	System.out.println("enter ID");
	eb_obj.setId(Integer.parseInt(sc.nextLine()));
	
	System.out.println("enter Name");
	eb_obj.setName(sc.nextLine());
	
	System.out.println("enter salary");
	eb_obj.setSalary(Double.parseDouble(sc.nextLine()));
	

	et.begin();
	em.persist(eb_obj);
	
	System.out.println("Record saved");
	
	et.commit();
	sc.close();
	em.close();
}
}
