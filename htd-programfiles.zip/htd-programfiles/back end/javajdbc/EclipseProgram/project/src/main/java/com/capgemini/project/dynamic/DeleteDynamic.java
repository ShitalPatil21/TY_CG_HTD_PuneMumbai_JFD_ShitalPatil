package com.capgemini.project.dynamic;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class DeleteDynamic {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("emp");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		String str1="Delete from empbean where id=:id";
		
		Query que1= em.createQuery(str1);
		System.out.println("enter id");
		que1.setParameter("id", Integer.parseInt(sc.nextLine()));
		int result = que1.executeUpdate();
		et.commit();
		System.out.println("result = "+result);
		sc.close();
	}

}
