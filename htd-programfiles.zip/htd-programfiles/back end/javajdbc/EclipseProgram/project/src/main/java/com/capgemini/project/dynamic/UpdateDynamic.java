package com.capgemini.project.dynamic;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class UpdateDynamic {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("emp");
		EntityManager em = emf.createEntityManager();

		String jpql = "Update empbean set name=:name where id=:id";

		String jpql2 = "Update empbean set salary=:salary where id=:id";

		EntityTransaction et = em.getTransaction();

		et.begin();
		System.out.println("enter 1 to update name");
		System.out.println("enter 2 to update salary");
		int a = Integer.parseInt(sc.nextLine());
		if (a == 1) {
			System.out.println("...................");
			Query que = em.createQuery(jpql);
			System.out.println("enter Id where u want to update");
			que.setParameter("id", Integer.parseInt(sc.nextLine()));

			System.out.println("enter name");
			que.setParameter("name", sc.nextLine());

			int result = que.executeUpdate();
			et.commit();
			System.out.println("result" + result);
		} else if (a == 2) {
			System.out.println("...................");
			Query que2 = em.createQuery(jpql2);
	
			System.out.println("enter Id where u want to update");
			que2.setParameter("id", Integer.parseInt(sc.nextLine()));
			System.out.println("enter salary");
			que2.setParameter("salary", Double.parseDouble(sc.nextLine()));
			int result = que2.executeUpdate();
			et.commit();
			System.out.println("result" + result);
		}

		sc.close();
	}

}
