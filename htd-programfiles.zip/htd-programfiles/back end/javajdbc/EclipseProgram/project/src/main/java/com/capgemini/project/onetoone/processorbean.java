package com.capgemini.project.onetoone;

public class processorbean {

}
