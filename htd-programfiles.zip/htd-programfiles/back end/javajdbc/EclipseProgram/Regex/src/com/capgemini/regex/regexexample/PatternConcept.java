package com.capgemini.regex.regexexample;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternConcept {

	static Pattern pattern;
	static Matcher matcher;
	
	public static void main(String[] args) {
		pattern = Pattern.compile("\\d");			//  \\d for single digit
		matcher = pattern.matcher("2");				//true
		System.out.println("pattern \\d:"+matcher.matches());
		
		pattern = Pattern.compile("\\d+");			//  \\d+ for multiple digit
		matcher = pattern.matcher("555512");				//true
		System.out.println("pattern \\d+:"+matcher.matches());
		
		pattern = Pattern.compile("\\w");			//  \\w for single char
		matcher = pattern.matcher("a");				//true 
		System.out.println("pattern \\w:"+matcher.matches());
		
		pattern = Pattern.compile("\\w+");			//  \\w+ for multiple char
		matcher = pattern.matcher("adf");				//true 
		System.out.println("pattern \\w+:"+matcher.matches());
		
		pattern = Pattern.compile("\\D+");			//  \\D+ means it is not a character
		matcher = pattern.matcher("aishu");				//true
		System.out.println("pattern \\D+:"+matcher.matches());
	}
}

