package com.capgemini.regex.regexexample;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternConcepts2 {

	public static void main(String[] args) {

		Pattern pat2= Pattern.compile("\\d");
		Matcher mat2=pat2.matcher("1");
		System.out.println("Pattern d =  "+mat2.matches());
		
		Pattern pat= Pattern.compile("\\d+");			//  \\d+ for multiple digit
		Matcher mat= pat.matcher("555512");				//true
		System.out.println("pattern d+ = "+mat.matches());
		
		
		Pattern pat1= Pattern.compile("\\d{0,11}");
		Matcher mat1=pat1.matcher("");
		System.out.println("Pattern d{0,11}=  "+mat1.matches());
		
		Pattern pat4= Pattern.compile("\\D");
		Matcher mat4=pat4.matcher("A");
		System.out.println("Pattern D =  "+mat4.matches());
		
		Pattern pat5= Pattern.compile("\\D+");
		Matcher mat5=pat5.matcher("Aishu");
		System.out.println("Pattern D+ =  "+mat5.matches());
		
		
		Pattern pat6= Pattern.compile("\\s");
		Matcher mat6=pat6.matcher(" ");
		System.out.println("Pattern s =  "+mat6.matches());

		Pattern pat7= Pattern.compile("\\s+");
		Matcher mat7=pat7.matcher("    ");
		System.out.println("Pattern s+ =  "+mat7.matches());
		
		Pattern pat8= Pattern.compile("\\S");
		Matcher mat8=pat8.matcher("aishu sakhare");
		System.out.println("Pattern S =  "+mat8.matches());

	}

}
