package com.capgemini.currancy;

import java.util.Currency;
import java.util.Set;

public class CurrancyExample {

	public static void main(String[] args) {

		Currency CurrancyCode1 = Currency.getInstance("INR");
		Currency CurrancyCode2 = Currency.getInstance("USD");
		
		String CurrancyCode1Symbol = CurrancyCode1.getSymbol();
		String CurrancyCode2Symbol = CurrancyCode2.getSymbol();
		
		System.out.println("Symbol for INR = "+CurrancyCode1Symbol);
		System.out.println("Symbol for USD = "+CurrancyCode2Symbol);
		System.out.println("...................................");
		
		String CurrancyCode1DisplayName =  CurrancyCode1.getDisplayName();
		String CurrancyCode2DisplayName =  CurrancyCode2.getDisplayName();
		
		System.out.println("Display name for INR = "+CurrancyCode1DisplayName);
		System.out.println("Display name for USD = "+CurrancyCode2DisplayName);
		System.out.println("...................................");
		
		Set<Currency> currancies = Currency.getAvailableCurrencies();
		System.out.println(currancies);
		System.out.println("...................................");
		
		int DafaultFraction1 = CurrancyCode1.getDefaultFractionDigits();
		int DafaultFraction2 = CurrancyCode2.getDefaultFractionDigits();
		
		System.out.println("Default fraction for INR = "+DafaultFraction1);
		System.out.println("Default fraction for USD = "+DafaultFraction2);
		System.out.println("...................................");
		
	}

}
