package com.capgemini.student;

import java.util.ArrayList;
import java.util.Collections;

public class TestS {
	public static void main(String[] args) {
		
	
	ArrayList li = new ArrayList();
	
	li.add('A');
	li.add('E');
	li.add('Z');
	li.add('B');
	
	
	System.out.println("before"+li);
	
	Collections.sort(li);
	
	System.out.println("after"+li);
}

}

