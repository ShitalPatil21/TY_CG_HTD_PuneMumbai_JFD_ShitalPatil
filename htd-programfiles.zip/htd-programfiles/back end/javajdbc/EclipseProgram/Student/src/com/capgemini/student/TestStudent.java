package com.capgemini.student;

import java.util.ArrayList;

public class TestStudent {

	public static void main(String[] args) {

			ArrayList<Student> al =new ArrayList<Student>();
			
			Student s1 = new Student(1,"Aishu",85.6);
			Student s2 = new Student(1,"Hrishi",50.6);
			Student s3 = new Student(1,"Ketaki",70.5);
			Student s4 = new Student(1,"Abhi",45.5);
			
			al.add(s1);
			al.add(s2);
			al.add(s3);
			al.add(s4);
			
			for(int i=0;i<2;i++)
			{
				Student r = al.get(i);
				
				System.out.println(r);
					
			}
			
		
		}


}
