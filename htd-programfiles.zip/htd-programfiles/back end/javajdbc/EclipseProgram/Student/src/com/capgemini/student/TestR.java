package com.capgemini.student;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class TestR {

	public static void main(String[] args) {
		
		ArrayList li = new ArrayList();
		
		/*
		 * li.add("Aishu"); li.add('E'); li.add(1); li.add(5.2);
		 */ 
		
		//classcastException
		
		
		
		
		li.add('A');
		li.add('E');
		li.add('Z');
		li.add('B');
		
		
		System.out.println("before"+li);
		
		Collections.sort(li);
		
		System.out.println("after"+li);
	}

}
