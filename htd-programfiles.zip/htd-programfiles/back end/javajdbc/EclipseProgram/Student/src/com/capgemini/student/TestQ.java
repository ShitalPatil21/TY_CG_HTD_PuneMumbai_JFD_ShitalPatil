package com.capgemini.student;

import java.util.Collections;
import java.util.LinkedList;

public class TestQ {
	public static void main(String[] args) {
		LinkedList<Double> li = new LinkedList <Double>();
		li.add(1.1);
		li.add(2.2);
		li.add(55.7);
		li.add(1.0);
		
		
		System.out.println("before"+li);
		
		Collections.sort(li);
		
		System.out.println("after"+li);
	}

}
