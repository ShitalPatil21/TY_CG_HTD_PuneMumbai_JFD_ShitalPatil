package com.capgemini.student;

public class Student {
	
	int ID;
	String name;
	double percentage;

	Student(int ID,String Name,double percentage)
	{
		this.ID = ID;
		this.name = Name;
		this.percentage = percentage;
		
	}
	
	

}
