package com.capgemini.student;

import java.util.ArrayList;



public class StudentHelper {
	 void display(ArrayList<Student> al)
	 {
	 for(Student e :al)
		{
		 			System.out.println("Student name = "+e.name);
					System.out.println("Student ID = "+e.ID);
					System.out.println("Student Percentage = "+e.percentage);
					System.out.println("....................");
		  
		}
	 checkpass(al);

	 }
	 
	 void checkpass(ArrayList<Student> al)
	 {
		 for(Student e :al)
			{
			 			System.out.println("Students those are pass");
			 			if(e.percentage>60)
			 			System.out.println("Student name = "+e.name);
						System.out.println("Student ID = "+e.ID);
						System.out.println("Student Percentage = "+e.percentage);
						System.out.println("....................");
			  
			}
		 
	 }


}
