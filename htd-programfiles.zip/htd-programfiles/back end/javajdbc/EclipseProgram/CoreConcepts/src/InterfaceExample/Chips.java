package InterfaceExample;

public interface Chips {
	
	void open();
	void eat();

}
