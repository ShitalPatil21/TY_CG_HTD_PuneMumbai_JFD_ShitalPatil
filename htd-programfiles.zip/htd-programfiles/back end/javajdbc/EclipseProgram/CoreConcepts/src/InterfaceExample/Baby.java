package InterfaceExample;

public class Baby {
	
	void recive(Chips c)
	{
		c.open();
		c.eat();
	}

}
