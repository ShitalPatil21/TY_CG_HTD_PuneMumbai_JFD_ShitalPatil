package InterfaceExample;

public class Kurkure implements Chips{

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("Kurkure open");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("Kurkure eat");
	}

}
