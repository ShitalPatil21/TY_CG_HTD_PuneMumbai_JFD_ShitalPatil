package InterfaceExample;

public class Bingo implements Chips {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("Bingo Open");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("bingo eat");
	}

}
