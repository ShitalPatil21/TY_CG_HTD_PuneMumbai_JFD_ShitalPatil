package InterfaceExample;

public class Lays implements Chips {
	@Override
	public void open()
	{
		System.out.println("Lays open");
	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("lays eat");
	}

}
