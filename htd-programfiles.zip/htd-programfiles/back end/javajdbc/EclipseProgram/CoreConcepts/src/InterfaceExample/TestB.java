package InterfaceExample;


public class TestB {
	
	public static void main(String []args)
	{
		
		Bingo bi=new Bingo();
		
		Lays L1=new Lays();
		
		
		Baby b= new Baby();
		b.recive(L1);
		b.recive(bi);
	}

}
