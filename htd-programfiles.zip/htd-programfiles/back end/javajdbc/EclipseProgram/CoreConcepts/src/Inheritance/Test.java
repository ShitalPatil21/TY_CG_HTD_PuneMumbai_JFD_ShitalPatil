package Inheritance;

public abstract class Test extends Demo implements InterfaceExample  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	@Override 
	public void print()
	{
		
		
		
	}
	@Override 
	public void add()
	{
		
		
		
	}
}
