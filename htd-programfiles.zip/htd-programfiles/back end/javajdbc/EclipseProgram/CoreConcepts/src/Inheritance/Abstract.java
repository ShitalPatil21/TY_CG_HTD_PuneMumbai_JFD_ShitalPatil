package Inheritance;

public class Abstract {

}
