package Inheritance;

public class Father extends GrandFather implements InterfaceExample{
	
	String fname="Eknath";
	
	public static void main(String [] args)
	{
		Father obj=new Father();
		obj.print();
		obj.display();
		obj.show();
	}
	
	@Override
	public void print()
	{
		System.out.println(fname+" "+" "+name+" "+lastname);
		super.print();
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub 
		System.out.println("display method in father Eknath");
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("show method in father Eknath");
	}
	
}
