package Inheritance;

public class GrandFather {
	
	String name="Kamlakar";
	String lastname="Sakhare";
	
	public static void main(String [] args)
	{
		GrandFather obj=new GrandFather();
		obj.print();
		
	}
	
	public void print()
	{
		System.out.println(name+" "+ lastname);
	}

}
