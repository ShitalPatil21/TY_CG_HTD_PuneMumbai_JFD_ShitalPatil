package Inheritance;

public class Daughter extends Father implements InterfaceExample{

	String dname="Aishwarya";
	public static void main(String [] args)
	{
		Daughter obj=new Daughter();
		obj.print();
		obj.display();
		obj.show();
	}
	@Override
	public void print()
	{
		System.out.println(dname+" "+" "+fname+" "+lastname);
		super.print();
	}
	
	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("display method in Daughter Aishwarya");
		
	}
	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("show method in Daughter Aishwarya");
		
	}
	
	

}
