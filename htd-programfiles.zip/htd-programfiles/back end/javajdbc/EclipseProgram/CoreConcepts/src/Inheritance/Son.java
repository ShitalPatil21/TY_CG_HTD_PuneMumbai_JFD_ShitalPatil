package Inheritance;

public class Son  extends Father implements InterfaceExample{

	String sname="Abhishek";
	public static void main(String [] args)
	{
		Son obj=new Son();
		obj.print();
		obj.display();
		obj.show();
	}
	
	@Override
	public void print()
	{
		System.out.println(sname+" "+" "+fname+" "+lastname);
		super.print();
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("display method in son Abhishek");
		
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("show method in son Abhishek");
	}
	
}
