package Inheritance;

public abstract class Demo {

	/*
	 * public static void main(String[] args) { // TODO Auto-generated method stub
	 * 
	 * }
	 */public abstract void print();
	 public abstract void add();
		
	
	
}
