package Inheritance;

public interface InterfaceExample {
	
	/*
	 * public void display() {			// we cant create a body
	 * 
	 * }
	 */
	
	public void display();
	public void show();
	
//	public static void ABC()
//	{
//										// we can create body for static methhod
//	}
//	
}
