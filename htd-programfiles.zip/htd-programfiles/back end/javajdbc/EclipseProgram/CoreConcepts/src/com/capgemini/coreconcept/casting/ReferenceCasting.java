package com.capgemini.coreconcept.casting;

public class ReferenceCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		A obj1=new B();		//upcasting
		B obj2=(B)obj1;		//downcasting
		
		obj2.cost=100;
		obj2.Write();
		System.out.println(obj2.str2);
		obj2.price=55.2;
		obj2.color();
		System.out.println(obj2.str1);
		
		
		
	}

}
