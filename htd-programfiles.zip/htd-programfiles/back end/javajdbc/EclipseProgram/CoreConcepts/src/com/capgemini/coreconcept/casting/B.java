package com.capgemini.coreconcept.casting;

public class B extends A
{
	
	double price;
	String str1="class B";
	void color()
	{
		System.out.println("From class B color method");
		System.out.println("price"+price);
	}


}
