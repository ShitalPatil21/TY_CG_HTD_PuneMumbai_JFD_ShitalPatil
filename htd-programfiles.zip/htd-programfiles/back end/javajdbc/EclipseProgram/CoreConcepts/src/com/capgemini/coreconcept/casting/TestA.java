package com.capgemini.coreconcept.casting;

public class TestA {
	public static void main(String []args)
	{
		byte a= 20;
		int b = a;			//implicite //op = 20
		System.out.println(b); 
		
		double c = 3.78;
		int d = (int) c;	//explicite  //o/p=3 //datalose
		System.out.println(d);
	}

}
