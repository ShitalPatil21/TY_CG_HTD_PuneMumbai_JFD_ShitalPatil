package com.capgemini.coreconcept.casting;

public class A {
	
	int cost;
	String str2="class A";
	void Write()
	{
		System.out.println("From class A write method");
		System.out.println("cost"+cost);
	}

}
