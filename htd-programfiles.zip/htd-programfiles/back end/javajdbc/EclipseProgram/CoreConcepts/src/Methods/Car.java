package Methods;

public class Car {

	String name;
	String color;
	double price;

	public Car() {													//Zero argument constructor

	}

	//source=> generate constructor using fields =>it will directly create this constructor
	public Car(String name, String color, double price) {			//parameterized constructor

		this.name = name;
		this.color = color;
		this.price = price;
	}


	public Car(String name, double price) {
		
	}
													//Constructor Overloading
	public Car(double price,String name) {

	}
	


	//source=> generate toString  =>it will directly create this toString
	@Override
	public String toString() {				//printing method
		return "Car [name=" + name + ", color=" + color + ", price=" + price + "]";
	}

}
