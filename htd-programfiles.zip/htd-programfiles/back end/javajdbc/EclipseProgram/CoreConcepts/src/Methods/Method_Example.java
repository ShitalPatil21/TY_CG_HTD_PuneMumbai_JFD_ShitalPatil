package Methods;

public class Method_Example {
	
	public static void main(String [] args)
	{
		test();										//test method calling
		System.out.println("******************");
		int side=areaofsquare(10);					// areaofsquare method calling
		System.out.println("areaofsquare = "+side);
		System.out.println("******************");
		int area=areaofrectangle(6,7);
		System.out.println(area);
		
		
	}
	
	
	public static void test()			//test method without parameter
	{
		System.out.println("Test() method");
	}
	
	public static int areaofsquare(int a)  //areaofsquare method with parameter
	{
		System.out.println("areaofsquare() method");
		a=a*a;
		return a;
	}

	
	public static int areaofrectangle(int a,int b)  //areaofrectangle method with parameter
	{
		System.out.println("areaofrectangle() method");
		int c=a*b;
		return c;
	}
}
