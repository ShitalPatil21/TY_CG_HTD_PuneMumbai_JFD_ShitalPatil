package Methods;

public class Demo {
	
	 static Method_Example me = new Method_Example();  //we have to use static before creating the object
	 													// so that we can access it in main method
	 	
	
	public static void main(String [] abc)
	{
		
		  Method_Example me1 = new Method_Example(); 
		  System.out.println(me1);						//output = address
		 
		  
		
		System.out.println(me);						//output = address
		//Cannot make a static reference to the non-static field me   //without static
		
		
		int a=Method_Example.areaofrectangle(8, 9);
		System.out.println(a);	
		int b=Method_Example.areaofrectangle(8, 9);
		
		System.out.println(b);	
	}

}
