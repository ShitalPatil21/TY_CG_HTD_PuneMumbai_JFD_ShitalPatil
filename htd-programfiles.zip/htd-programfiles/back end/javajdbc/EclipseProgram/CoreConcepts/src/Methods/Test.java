package Methods;

public class Test {

	public static void main(String [] abc)
	{
		
		Car obj=new Car("ODI","Red",2200.8000655);			//car class object
		
		System.out.println(print(obj));
		
	}
							//object						//Car is a class name
	public static  Car print(Car car)				//we can use "CAR" as a return type 
	{												//Car as a Reference type
		return car;									//Car is a return statement
	}
}
