package Methods;

public class MethodOverloadingExample {
	
	public static int Add(int i,int j)
	{
		return i+j;
	}
	
	public static int Add(int i , int j, int k)
	{
		return i+j+k;
	}											
																			//method overloading
	public static double Add(int i,int j , double d)
	{
		return i+j+d;
	}
	
	public static double Add(int i,double d,int j )
	{
		
		return i+j+d;
	}
	
	
	
	public static void main(String [] abc)
	{
		System.out.println("Add(int i,int j) = "+Add(5,6));
		System.out.println("Add(int i,int j, int k) = "+Add(5,6,4));
		System.out.println("Add(int i,int j , double d) = "+Add(5,6,4.5));
		System.out.println("Add(int i,double d,int j ) = "+Add(5,2.,6));
	}

}
