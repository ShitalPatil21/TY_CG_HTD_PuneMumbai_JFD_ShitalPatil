package AbstractionExample;

public interface ATM {
	
	void validateCard();
	void getInfo();
	

}
