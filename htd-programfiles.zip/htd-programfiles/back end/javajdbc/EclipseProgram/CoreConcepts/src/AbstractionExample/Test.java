package AbstractionExample;

public class Test {
	public static void main(String []args)
	{
		Machine m=new Machine();
		
		HDFC h=new HDFC();
		
		ICICI i=new ICICI();
		
		SBI s=new SBI();
		
		m.sloat(s);
		m.sloat(h);
		m.sloat(i);
	}

}
