package AbstractionExample;

public class HDFC implements ATM{

	@Override
	public void validateCard() {
		// TODO Auto-generated method stub
		System.out.println(".......connecting to HDFC");
		System.out.println("I am validating the HDFC card");

	}

	@Override
	public void getInfo() {
		// TODO Auto-generated method stub
		System.out.println(".......connecting to HDFC");
		System.out.println("I am getting the HDFC account holder no");
	}

}
