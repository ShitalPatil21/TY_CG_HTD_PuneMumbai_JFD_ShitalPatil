package AbstractionExample;

public class SBI implements ATM{

	@Override
	public void validateCard() {
		// TODO Auto-generated method stub
		System.out.println(".......connecting to SBI");
		System.out.println("I am validating the SBI card");
	}

	@Override
	public void getInfo() {
		// TODO Auto-generated method stub
		System.out.println(".......connecting to SBI");
		System.out.println("I am getting the SBI account holder no");
	}

}
