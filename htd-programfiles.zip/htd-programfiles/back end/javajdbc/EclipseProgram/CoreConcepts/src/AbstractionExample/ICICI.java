package AbstractionExample;

public class ICICI implements ATM{

	@Override
	public void validateCard() {
		// TODO Auto-generated method stub
		System.out.println(".......connecting to ICICI");
		System.out.println("I am validating the ICICI card");
	}

	@Override
	public void getInfo() {
		// TODO Auto-generated method stub
		System.out.println(".......connecting to ICICI");
		System.out.println("I am getting the ICICI account holder no");
	}

}
