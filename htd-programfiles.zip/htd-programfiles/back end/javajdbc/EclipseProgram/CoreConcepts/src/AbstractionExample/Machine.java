package AbstractionExample;

public class Machine {
	
	void sloat(ATM a)
	{
		a.validateCard();
		a.getInfo();
	}

}
