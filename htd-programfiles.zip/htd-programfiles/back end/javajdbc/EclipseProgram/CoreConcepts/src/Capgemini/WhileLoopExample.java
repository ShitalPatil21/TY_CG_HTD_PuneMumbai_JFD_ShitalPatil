package Capgemini;

public class WhileLoopExample {
	
	public static void main(String [] args)
	{
		int i =1;
						
		/*
		 * while(i<20) { System.out.println("i"+i); }	// infinte loop
		 */
		
//		while(true)
//		{
//			System.out.println("i"+i);
//		}
//		System.out.println("out of loop"); // it will give an error unreachable statement error coz the condition is always true
	
		
		while(i<=10)
		{
			System.out.println("I ="+i); //print the i for 10 times
			i++;
		}
	}
}
