package Capgemini;

public class DoWhileLoopExample {
	

	public static void main(String [] args)
	{
		int i=1;
		//print the values 1 to 5
		do {
			System.out.println("i = "+i);
			i++;
		}
		while(i<=5);
		
		
		System.out.println("#######################################");
		int b=11;
		//here it will print output at least one
		do {
			System.out.println("i = "+b);
			b++;
		}
		while(b<=5);
		
		
		System.out.println("code outside the loop");
	}
}
