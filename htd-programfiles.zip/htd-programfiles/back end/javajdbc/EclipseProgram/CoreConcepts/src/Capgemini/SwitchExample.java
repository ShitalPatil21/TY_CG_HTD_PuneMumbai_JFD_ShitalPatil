package Capgemini;

public class SwitchExample {

	public static void main(String[] args) {
		int num = 5;
		switch (num) {				//check the day

		case 1:
			System.out.println("MON");
			break;
		case 2:
			System.out.println("TUE");
			break;
		case 3:
			System.out.println("WEN");
			break;
		case 4:
			System.out.println("TH");
			break;
		case 5:
			System.out.println("FRI");
			break;
		case 6:
			System.out.println("SAT");
			break;
		case 7:
			System.out.println("SUN");
			break;
		default:
			System.out.println("Invalid number");

		}

		switch (num) {    			//check for weekdays or weekends

		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			System.out.println("Week days");
			break;
		case 6:
		case 7:
			System.out.println("Week Ends");
			break;

		default:
			System.out.println("Invalid number");

		}

	}

}
