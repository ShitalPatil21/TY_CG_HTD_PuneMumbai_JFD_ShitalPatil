package Capgemini;

public class ForLoopExample {
	
	public static void main(String [] args)
	{
		//printing number five times
		
		for(int i=1; i<=5;i++)
		{
			System.out.println("* i value = "+i);
		}
		
		System.out.println("out of for loop");
		
		System.out.println("#######################################");
		
//		for(; ;)
//		{
//			System.out.println("*");		//infinite loop
//		}
//		System.out.println("out of for loop");  //here it will give unreachable error
		
		//Check the number for even or odd
		
		//System.out.println("#######################################");
		
		for(int j=1;j<=10;j++)
		{
			if(j%2==0)
			{
				System.out.println("Even number = "+j); 	//even number
			}
			else
			{
				System.out.println("Odd number ="+j);		//odd number
			}
		}
		
		System.out.println("#######################################");
		
		//looping statements inside the condition statement
		
		int a=10;
		if(a%2==0)
		{
			for(int k=1;k<=a;k++)
			{
				System.out.println(k);
			}
		}
		
		System.out.println("#######################################");
	}
	

}
