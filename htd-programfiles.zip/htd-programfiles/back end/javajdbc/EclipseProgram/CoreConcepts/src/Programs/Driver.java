package Programs;

public class Driver {
	
	
	void reciver(Car c)
	{
		c.move();
	}
}
