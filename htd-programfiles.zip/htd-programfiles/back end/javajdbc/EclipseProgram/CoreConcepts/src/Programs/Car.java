package Programs;

public class Car {
	void move()
	{
		System.out.println("I am moving");
	}

}
