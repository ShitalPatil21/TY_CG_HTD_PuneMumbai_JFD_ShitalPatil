package com.capgemini.MavenAssignment;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.mavenasign.dto.Student11;



public class insertStudent {
	public static void main(String[] args) {
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		
		Scanner sc = new Scanner(System.in);
		
		Student11 movie=new Student11();
		
		System.out.println("Enter ID");
		movie.setId(Integer.parseInt(sc.nextLine()));
		System.out.println("Enter Name");
		movie.setName(sc.nextLine());
				sc.close();
		
		try 
		{
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("test");
			 entityManager = entityManagerFactory.createEntityManager();
			 entityTransaction = entityManager.getTransaction();
			
			entityTransaction.begin();
			entityManager.persist(movie);
			
			System.out.println("Record Saved");
			entityTransaction.commit();
		}//end of try 
		
		catch (Exception e) 
		{
			entityTransaction.rollback();
			e.printStackTrace();
			
		}//end of catch
		
		entityManager.close();
	}//end of main


}
