package com.capgemini.MavenAssignment;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.mavenasign.dto.Student11;



public class readStudent {

	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("test");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
				
		Student11 data=entityManager.find(Student11.class, "aishu");
		System.out.println("ID     = "+data.getId());
		System.out.println("Name   = "+data.getName());
		
		
		
	}//end of main

}
