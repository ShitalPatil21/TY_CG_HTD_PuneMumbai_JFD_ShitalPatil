package com.capgemini.MavenAssignment;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.mavenasign.dto.Student11;



public class deleteStudent {
	public static void main(String[] args) {
		
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		
		
		
		
		try 
		{
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("test");
			 entityManager = entityManagerFactory.createEntityManager();
			 entityTransaction = entityManager.getTransaction();
			
			entityTransaction.begin();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter name which you want to delte");
			
			Student11 data = entityManager.find(Student11.class, sc.nextLine());
			entityManager.remove(data);
			
			System.out.println("Record Delete");
			entityTransaction.commit();
			
			sc.close();
		}//end of try 
		
		catch (Exception e) 
		{
			entityTransaction.rollback();
			e.printStackTrace();
			
		}//end of catch
		
		entityManager.close();

	}

}
