package com.capgemini.stream.employee;

public class Employee {
	
	String Name;
	int ID;
	double Height;
	
	public Employee(String name, int iD, double height) {
		super();
		Name = name;
		ID = iD;
		Height = height;
	}
	
	

}
