package com.caogemini.stream.queue;

public class Employee {
	
	String name;
	int id;
	public Employee(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	
	

}
