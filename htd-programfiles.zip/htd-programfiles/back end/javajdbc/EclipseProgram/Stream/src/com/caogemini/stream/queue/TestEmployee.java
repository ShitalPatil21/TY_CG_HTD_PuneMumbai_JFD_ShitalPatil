package com.caogemini.stream.queue;

import java.util.ArrayList;

public class TestEmployee {
	public static void main(String[] args) {
		
	}

}
