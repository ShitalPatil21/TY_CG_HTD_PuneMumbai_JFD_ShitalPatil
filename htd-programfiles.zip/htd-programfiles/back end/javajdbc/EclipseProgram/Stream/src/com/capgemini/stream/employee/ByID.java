package com.capgemini.stream.employee;

import java.util.Comparator;
import java.util.Iterator;
import java.util.TreeSet;

public class ByID {
public static void main(String[] args) {
		
		
		Comparator<Employee> compid = (e1,e2)->{
			if(e1.ID>e2.ID)
			{
				return 1;
			}
			else if(e1.ID<e2.ID)
			{
				return -1;
			}
			else
			{
				return 0;
			}
		};
		
			
		TreeSet<Employee> ts =new TreeSet<Employee>(compid);
		
		Employee e1 = new Employee("Aishwarya",3,4.2);
		Employee e2 = new Employee("Hrishikesh",1,5.2);
		Employee e3 = new Employee("Abhishek",2,2.2);
		
		ts.add(e1);
		ts.add(e2);
		ts.add(e3);
		
		Iterator <Employee>it = ts.iterator();
		while(it.hasNext())
		{
			Employee e = it.next();
			System.out.println("Name = "+e.Name);
			System.out.println("ID = "+e.ID);
			System.out.println("Height = "+e.Height);
		}
	}


}
