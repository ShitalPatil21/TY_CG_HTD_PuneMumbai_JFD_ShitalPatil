package com.capgemini.studentbean.bean;

import java.util.Comparator;

public class ByID implements Comparator<StudentBean> {

	@Override
	public int compare(StudentBean o1, StudentBean o2) {
		
		if(o1.getID()>o2.getID())
		{
			return 1;
		}
		else if(o2.getID()>o1.getID())
		{
			return -1;
		}
		else {
		return 0;
		}
	}
	
	

}
