package com.capgemini.studentbean.bean;

import java.util.Iterator;
import java.util.TreeSet;

public class StudentBeanTest {
	public static void main(String[] args) {
		
		ByID sid = new ByID();
	
		TreeSet<StudentBean> ts = new TreeSet<StudentBean>(sid);
		
		StudentBean s1 = new StudentBean();
		s1.setID(1);
		s1.setName("Aishwarya");
		s1.setPercentage(80.2);
		s1.setGender('F');
		
		
		StudentBean s2 = new StudentBean();
		s2.setID(2);
		s2.setName("Hrishikesh");
		s2.setPercentage(30.2);
		s2.setGender('M');
		
		
		StudentBean s3 = new StudentBean();
		s3.setID(3);
		s3.setName("Ketaki");
		s3.setPercentage(45.2);
		s3.setGender('F');
		
		StudentBean s4 = new StudentBean();
		s4.setID(4);
		s4.setName("Abhishek");
		s4.setPercentage(68.2);
		s4.setGender('M');
		
		StudentBean s5 = new StudentBean();
		s5.setID(5);
		s5.setName("Atharva");
		s5.setPercentage(45.2);
		s5.setGender('M');
		
		
		ts.add(s1);
		ts.add(s2);
		ts.add(s3);
		ts.add(s4);
		ts.add(s5);
		
		for(StudentBean sb : ts)
		{
			System.out.println("Name = "+sb.getName());
			System.out.println("ID = "+sb.getID());
			System.out.println("Percentage = "+sb.getPercentage());
			System.out.println("Gender = "+sb.getGender());
	}
	}
}
