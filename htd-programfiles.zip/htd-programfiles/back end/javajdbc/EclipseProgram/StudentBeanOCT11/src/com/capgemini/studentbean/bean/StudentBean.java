package com.capgemini.studentbean.bean;

import java.util.TreeSet;

public class StudentBean {
	
	private String Name;
	private int ID;
	private double Percentage;
	private char Gender;
	

//getter setter method
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public double getPercentage() {
		return Percentage;
	}
	public void setPercentage(double percentage) {
		Percentage = percentage;
	}
	public char getGender() {
		return Gender;
	}
	public void setGender(char gender) {
		Gender = gender;
	}
	
	
	
}
