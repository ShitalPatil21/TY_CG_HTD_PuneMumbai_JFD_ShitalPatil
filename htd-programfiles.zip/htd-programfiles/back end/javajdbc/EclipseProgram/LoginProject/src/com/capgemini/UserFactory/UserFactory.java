package com.capgemini.UserFactory;

import com.capgemini.UserInterface.UserInterface;
import com.capgemini.UserJDBC.UserJDBC;

public class UserFactory {
	private UserFactory()
	{
		
	}

	public static UserInterface getInstance() {
		UserInterface dao = new UserJDBC();
		return dao;
	}


}
