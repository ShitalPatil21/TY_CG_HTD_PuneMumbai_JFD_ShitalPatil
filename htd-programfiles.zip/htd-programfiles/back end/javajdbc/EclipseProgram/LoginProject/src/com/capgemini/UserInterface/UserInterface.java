package com.capgemini.UserInterface;

import java.util.List;

import com.capgemini.UserInformation.UserInfo;

public interface UserInterface {
	public List<UserInfo> getAllInfo();
	public UserInfo getInfo(int userid,String password);
	public UserInfo getAllUser();
	}
