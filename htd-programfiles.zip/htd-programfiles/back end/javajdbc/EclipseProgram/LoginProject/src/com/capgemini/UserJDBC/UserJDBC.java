package com.capgemini.UserJDBC;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.capgemini.UserInformation.UserInfo;
import com.capgemini.UserInterface.UserInterface;

public class UserJDBC implements UserInterface {
	FileReader reader = null;
	Properties prop = null;
	UserInfo user = null;
	ResultSet rs = null;
	Statement stmt = null;

//constructor	
	public UserJDBC() 
	{
		try
		{
			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);
			Class.forName(prop.getProperty("driverClass"));
			System.out.println("Driver Loaded...");
			System.out.println("*************************");
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	
//getInfo method scan username and userpassword
	@Override
	public UserInfo getInfo(int userid, String password)
	{

		try (Connection conn = DriverManager.getConnection
				(	prop.getProperty("dburl"), 
					prop.getProperty("user"),
					prop.getProperty("password")
				);
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query1"))
			) 
		{

			pstmt.setInt(1, userid);
			pstmt.setString(2, password);

			try (ResultSet rs = pstmt.executeQuery()) 
			{
				if (rs.next()) 
				{
					user = new UserInfo();
					user.setUserid(rs.getInt(1));
					user.setUsername(rs.getString(2));
					user.setEmail(rs.getString(3));
				}
				return user;
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return null;
	}

//getAllInfo by list using arraylist
	@Override
	public List<UserInfo> getAllInfo()
	{
		List<UserInfo> userlist = new ArrayList<UserInfo>();

		try (Connection conn = DriverManager.getConnection
				(prop.getProperty("dburl"),
				prop.getProperty("user"),
				prop.getProperty("password"));
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(prop.getProperty("query")))

		{

			while (rs.next()) 
			{
				user = new UserInfo();
				user.setUserid(rs.getInt(1));
				user.setEmail(rs.getString(2));
				user.setPassword(rs.getString(3));
				user.setUsername(rs.getString(4));

				userlist.add(user);
			}

			return userlist;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}

		return null;
	}

	
//getAlluser info using statement
	@Override
	public UserInfo getAllUser() {

		try (Connection conn = DriverManager.getConnection
				(prop.getProperty("dburl"), 
				prop.getProperty("user"),
				prop.getProperty("password"));
				Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery(prop.getProperty("query")))
		{
			while (rs.next())
			{				
				System.out.println("user Id : " + rs.getInt(1));
				System.out.println("user name : " + rs.getString("username"));
				System.out.println("Email : " + rs.getString(3));
				System.out.println("Password : " + rs.getString("password"));
				System.out.println("************************");
			}

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}

		return null;
	}

}
