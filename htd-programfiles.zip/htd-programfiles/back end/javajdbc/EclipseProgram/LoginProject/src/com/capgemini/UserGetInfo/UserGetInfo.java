package com.capgemini.UserGetInfo;

import java.util.List;
import java.util.Scanner;

import com.capgemini.UserFactory.UserFactory;
import com.capgemini.UserInformation.UserInfo;
import com.capgemini.UserInterface.UserInterface;

public class UserGetInfo {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		UserInterface dao = UserFactory.getInstance();

		List<UserInfo> userlist = dao.getAllInfo();

		if (userlist != null) {
			for (UserInfo user : userlist) {
				System.out.println(user);
				System.out.println(".........................");
			}
		} else {
			System.out.println("Something went wrong ");
		}

		UserInfo user2 = dao.getAllUser();

		if (user2 != null) {
			System.out.println(user2);
		} else {
			System.out.println("Something went wrong ");
		}

		System.out.println("*****************************");
		System.out.println("Enter the user id : ");
		int userid = Integer.parseInt(sc.nextLine());

		System.out.println("Enter passsword");
		String password = sc.nextLine();

		UserInfo user1 = dao.getInfo(userid, password);
		if (user1 != null) {
			System.out.println(user1);
		} else {
			System.out.println("Something went wrong ");
		}
		sc.close();

	}
}
