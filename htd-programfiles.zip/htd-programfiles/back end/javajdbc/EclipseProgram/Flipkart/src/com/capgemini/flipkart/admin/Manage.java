package com.capgemini.flipkart.admin;

public class Manage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
