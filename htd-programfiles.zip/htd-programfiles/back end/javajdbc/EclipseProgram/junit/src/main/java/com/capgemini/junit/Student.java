package com.capgemini.junit;

public class Student {

	private int id;
	private String name;
	private float percentage;
	private char gender;
	
	//default constructor
	public Student() {
	}

	// parameterized constructor
	public Student(String name, float percentage, char gender) {
		
		//this.id = id;
		this.name = name;
		this.percentage = percentage;
		this.gender = gender;
	}


	//getter and setter
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
}// end of class
