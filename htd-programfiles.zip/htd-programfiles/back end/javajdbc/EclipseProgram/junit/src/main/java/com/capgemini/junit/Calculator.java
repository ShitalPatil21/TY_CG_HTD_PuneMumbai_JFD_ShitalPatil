package com.capgemini.junit;

public class Calculator {

	public int add(int a, int b) {
		return a + b;

	}// end of add

	public int multiply(int a, int b) {
		return a * b;

	}// end of multiply

	public int subtract(int a, int b) {
		return a - b;

	}// end of subtract

	public int divide(int a, int b) {
		return a /b;

	}// end of divide
	
	

}// end of class
