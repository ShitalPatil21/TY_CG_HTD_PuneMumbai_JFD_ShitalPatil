package com.capgemini.junit;

public class StudentSchoolTest {

	public static void main(String[] args) {

	}

}
