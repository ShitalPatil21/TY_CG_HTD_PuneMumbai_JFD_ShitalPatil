package com.capgemini.junit;

public class Factorail {

	public int factorial(int a) {
		int i,fact=1;  
		   
		  for(i=1;i<=a;i++){    
		      fact=fact*i;    
		  }    
		  return fact;   
		 

	}// end of add
}// end of class
