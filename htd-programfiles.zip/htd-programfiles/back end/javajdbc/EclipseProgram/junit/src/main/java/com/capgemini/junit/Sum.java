package com.capgemini.junit;

public class Sum {

	public int add(int a, int b) {
		return a + b;

	}// end of add
	
	public int add2(int a, int b,int c) {
		return a + b+c;

	}// end of add2

}// end of class
