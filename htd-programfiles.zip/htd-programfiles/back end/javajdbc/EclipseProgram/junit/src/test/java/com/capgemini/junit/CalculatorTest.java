package com.capgemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest {
	private Calculator calculator = null;
	
	@BeforeEach
	public void createObject() {
		calculator = new Calculator();
	}

	@Test
	public void addTest() {
		
		int i = calculator.add(10, 4);
		assertEquals(14, i);

	}// end of addTest()

	@Test
	public void addTestForNegative() {
		int i = calculator.add(-10, 4);
		assertEquals(-6, i);

	}// end of addTestForNegative()

	@Test
	public void subtractTest() {
		int i = calculator.subtract(10, 4);
		assertEquals(6, i);

	}// end of subtractTest()

	@Test
	public void multiplyTest() {
		int i = calculator.multiply(10, 4);
		assertEquals(40, i);

	}// end of multiplyTest()

	@Test
	public void divideTest() {
		int i = calculator.divide(10, 2);
		assertEquals(5, i);

	}// end of divideTest()

	@Test
	public void divideTestForZero() {
		
		assertThrows(ArithmeticException.class, () -> calculator.divide(10, 0));

	}// end of divideTestForZero()

}// end of class
