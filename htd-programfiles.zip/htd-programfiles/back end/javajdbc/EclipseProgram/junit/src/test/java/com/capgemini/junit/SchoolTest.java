package com.capgemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SchoolTest {

	private School school;
	
	@BeforeEach   
	public void createObject() {
		school = new School();
	}// end of createObject/
	
	
	@Test
	public void testRegisterStudent() {
		Student student = new Student("Aishwarya",(float) 80.20,'f');
		Student stu =school.registerStudent(student);
		assertEquals(1, stu.getId());
	}// end of testRegisterStudent
	

	@Test
	public void testRegisterStudentForNull() {
		assertThrows(NullPointerException.class, ()->school.registerStudent(null));
	}
}// end of class
