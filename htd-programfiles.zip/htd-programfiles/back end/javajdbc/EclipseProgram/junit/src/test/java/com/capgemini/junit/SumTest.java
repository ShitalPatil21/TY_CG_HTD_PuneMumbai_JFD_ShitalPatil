package com.capgemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SumTest {
	
	@Test
	public void addTest() {
		Sum s = new Sum();
		int i = s.add(10, 4);
		assertEquals(14,i);
		
	}// end of addTest()
	
	@Test
	public void addTest2() {
		Sum s = new Sum();
		int i = s.add2(10, 4,1);
		assertEquals(15,i);
		
	}// end of addTest()
	
}// end of class
