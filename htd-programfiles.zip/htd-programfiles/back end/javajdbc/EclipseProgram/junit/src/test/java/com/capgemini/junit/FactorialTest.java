package com.capgemini.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FactorialTest {

	@Test
	public void Factorialtest() {
		Factorail f = new Factorail();
		int i =f.factorial(5);
		assertEquals(120, i);
	}// end of factorialTest()
	
	@Test
	public void FactorialtestForZero() {
		Factorail f = new Factorail();
		int i =f.factorial(0);
		assertEquals(1, i);
	}// end of FactorialtestForZero()
	
	@Test
	public void FactorialtestForNegative() {
		Factorail f = new Factorail();
		int i =f.factorial(-8);
		assertEquals(1, i);
	}// end of FactorialtestForNegative()

}// end of class
