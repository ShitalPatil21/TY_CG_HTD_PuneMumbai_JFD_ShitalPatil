package com.capgemini.exceptionhandling.exceptionexample;

import java.io.File;
import java.io.IOException;

public class Bottle {

	void open() throws IOException, ClassNotFoundException
	{
	File f = new File("E://abhi.txt");
		
		f.createNewFile();
		
		Class.forName("com.capgemini.exceptionhandling.exceptionexample.Bottlen");
	}
}
