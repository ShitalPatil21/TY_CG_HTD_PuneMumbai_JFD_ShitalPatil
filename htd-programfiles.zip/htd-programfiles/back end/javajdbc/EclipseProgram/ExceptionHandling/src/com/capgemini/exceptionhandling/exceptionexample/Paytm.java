package com.capgemini.exceptionhandling.exceptionexample;

public class Paytm {

	void book()
	{
		System.out.println("book started");
		
		IRCTC obj = new IRCTC();
		//obj.confirm();

		try {
			obj.confirm();
			}
			catch(Exception e )
			{
				System.out.println("Exception handling in book method");
			}
		
		System.out.println("book ended");
	}
}
