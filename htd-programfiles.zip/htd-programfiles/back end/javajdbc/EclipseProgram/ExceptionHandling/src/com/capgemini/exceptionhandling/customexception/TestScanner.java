package com.capgemini.exceptionhandling.customexception;

import java.util.Scanner;

public class TestScanner {
	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in))
		{
			System.out.println("Enter the age");
			int age = sc.nextInt();
			System.out.println("age is"+age);
		}
	}

}
