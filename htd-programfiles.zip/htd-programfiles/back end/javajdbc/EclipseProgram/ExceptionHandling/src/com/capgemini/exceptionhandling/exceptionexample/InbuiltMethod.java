package com.capgemini.exceptionhandling.exceptionexample;

public class InbuiltMethod {
	public static void main(String[] args) {
		System.out.println("main started");
		int  a[]=new int[4];
		String s=null;
		try {
			System.out.println(10/0);
			System.out.println(a[2]);
			System.out.println(s.length());
		} 
		catch (ArrayIndexOutOfBoundsException |NullPointerException e) {
			e.printStackTrace();
		}
//		
//		catch (NullPointerException e) {
//			e.printStackTrace();
//		
//		}
		catch (Exception e) {
			//System.out.println();
			e.printStackTrace();
		}
		System.out.println("main ended");
	}

}
