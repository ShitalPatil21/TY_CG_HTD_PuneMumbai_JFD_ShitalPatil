package com.capgemini.exceptionhandling.customexception;

public class TestAmount {
	public static void main(String[] args) {
		Amount amt=new Amount();
		
		
		try {
			amt.check(500);
			System.out.println("valid");
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Invalid");
		}
	}

}
