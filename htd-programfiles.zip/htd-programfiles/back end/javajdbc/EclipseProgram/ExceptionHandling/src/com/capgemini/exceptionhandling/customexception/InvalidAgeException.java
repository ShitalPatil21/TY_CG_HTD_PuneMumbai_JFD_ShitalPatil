package com.capgemini.exceptionhandling.customexception;

public class InvalidAgeException extends RuntimeException {
	
	  
	  private String message = "Invalid age ";
//	  private String message;
//	  
//	  public InvalidAgeException(String message)
//	  {
//		  this.message=message;
//	  }
//	  
//	  
//	  public InvalidAgeException()
//	  {
//		  
//	  }
	  public String getMessage() { return message; }
	  
	  @Override public String toString() { return message; }
	 
}
