package com.capgemini.exceptionhandling.exceptionexample;

public class ArithmeticException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			System.out.println("main started");
			
			try
			{
				System.out.println(10/2);
				System.out.println(10/0);	//exception occur
				
				System.out.println(10/5); 	//not executed
				//here if exception occur it will not execute a further stmts	 
				//directly goes to catch block
				
			}
			catch (Exception e) {
				// TODO: handle exception
				System.out.println("please dont divied no by zero");
			}
			
			//System.out.println(10/0);
								//main started
								//Exception in thread "main" java.lang.ArithmeticException:
			
			System.out.println("main ended");
	}

}
