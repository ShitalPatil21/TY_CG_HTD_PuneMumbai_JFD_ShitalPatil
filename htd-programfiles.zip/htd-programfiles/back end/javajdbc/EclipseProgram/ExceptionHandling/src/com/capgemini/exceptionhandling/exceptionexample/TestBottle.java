package com.capgemini.exceptionhandling.exceptionexample;

import java.io.IOException;

public class TestBottle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bottle b = new Bottle();
		
		try {
			b.open();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
