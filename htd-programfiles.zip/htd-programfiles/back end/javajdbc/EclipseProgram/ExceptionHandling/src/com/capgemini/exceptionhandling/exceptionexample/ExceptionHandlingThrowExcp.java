package com.capgemini.exceptionhandling.exceptionexample;

import java.io.File;
import java.io.IOException;

public class ExceptionHandlingThrowExcp {
	void open() throws IOException
	{
		File f = new File("E://abhi.txt");
		
		f.createNewFile();
	}

}
