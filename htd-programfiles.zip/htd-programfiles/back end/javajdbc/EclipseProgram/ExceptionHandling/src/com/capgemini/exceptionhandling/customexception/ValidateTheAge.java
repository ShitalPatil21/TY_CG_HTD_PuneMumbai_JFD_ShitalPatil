package com.capgemini.exceptionhandling.customexception;

public class ValidateTheAge {
	
	void verify(int age)
	{
		if(age<18)
		{
			throw new InvalidAgeException();
		}
	}

}
