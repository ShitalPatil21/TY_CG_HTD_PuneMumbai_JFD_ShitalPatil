package com.capgemini.exceptionhandling.exceptionexample;

public class BMS {

	public static void main(String[] args) {
		
		System.out.println("main started");
		PVR obj = new PVR();
		try {
			obj.confirm();
		} catch (Exception e) {
			System.out.println("Exception handle in confirm() at BMS");
		}
		System.out.println("main ended");
		
	}

}
