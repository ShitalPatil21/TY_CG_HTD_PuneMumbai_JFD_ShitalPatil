package com.capgemini.exceptionhandling.customexception;

public class Amount {
	
	void check(int val) throws InvalidLimitException
	{
		if(val > 4000)
		{
			throw new InvalidLimitException();
		}
		
	}

}
