package com.capgemini.exceptionhandling.exceptionexample;

public class PVR {
	
	void confirm()
	{
		System.out.println("confirm started");
		
		try {
			System.out.println(10/0);
			
		} catch (Exception e) 
		{
			System.out.println("Exception handle in confirm() at PVR");
			throw e;
		}
		finally
		{
		System.out.println("confirm ended");
		}
	}
}
