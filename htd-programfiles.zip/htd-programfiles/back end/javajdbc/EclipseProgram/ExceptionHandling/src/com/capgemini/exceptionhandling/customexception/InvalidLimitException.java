package com.capgemini.exceptionhandling.customexception;

public class InvalidLimitException extends RuntimeException{
	
	private String message="Day limit is 4000";
	
	public String getMessage()
	{
		return message;
	}

}
