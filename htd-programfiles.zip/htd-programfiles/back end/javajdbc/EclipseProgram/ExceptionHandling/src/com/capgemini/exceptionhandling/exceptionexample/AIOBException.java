package com.capgemini.exceptionhandling.exceptionexample;




public class AIOBException  {

	public static void main(String[] args) {
		System.out.println("Main started");
		
		int[] arr=new int[4];
		String []st=null;
		try
		{
			System.out.println(arr[3]);
			System.out.println(st[1]);
			System.out.println(10/0);	//exception
		}
		catch (ArrayIndexOutOfBoundsException e) {
			//here we only accept AIOBE
			System.out.println("dont cross array index");
		}
//		catch(ArithmeticException i)
//		{
//			System.out.println("dont dived by zero");
//		}
		catch(NullPointerException n)
		{
			System.out.println("dont deal with null");
		}
		catch(Exception e )
		{
			System.out.println("something went wrong");
		}

		System.out.println("main ended");

}
}