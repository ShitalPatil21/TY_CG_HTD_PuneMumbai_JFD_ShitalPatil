package com.capgemini.exceptionhandling.exceptionexample;

public class IRCTC {

	void confirm()
	{
		System.out.println("confirm started");
		//System.out.println(10/0);
		try {
		System.out.println(10/0);
		}
		catch(Exception e )
		{
			System.out.println("Exception handle in confirm method");
		}
		System.out.println("confirm ended");
	}
}
