package com.capgemini.exceptionhandling.exceptionexample;

import java.io.File;
import java.io.IOException;

public class ExceptionHandlingTryCath {
	
	public static void main(String[] args) {
		File f = new File("E://Hrishi.txt");
		
		try {
			f.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
