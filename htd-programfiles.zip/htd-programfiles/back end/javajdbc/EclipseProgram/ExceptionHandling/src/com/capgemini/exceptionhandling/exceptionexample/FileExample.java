package com.capgemini.exceptionhandling.exceptionexample;

import java.io.File;

public class FileExample {
	public static void main(String[] args) {
		System.out.println("main started");
		File f = new File("E:\\Aishu.txt");
		try
		{
			f.createNewFile();
			System.out.println("File created");
		}
		catch (Exception e) 
		{
			System.out.println("sorry not able to create file");
		}
		
		System.out.println("main ended");
	}

}
