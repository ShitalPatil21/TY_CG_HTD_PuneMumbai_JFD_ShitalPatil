package com.capgemini.exceptionhandling.customexception;

public class TestValidateAge {

	public static void main(String[] args) {

		ValidateTheAge vage=new ValidateTheAge();
		vage.verify(2);
		System.out.println("Valid age");
		
//		try {
//			vage.verify(5);
//			System.out.println("Valid age");
//		} catch (Exception e) {
//			//System.out.println("Invalid age");
//			//e.printStackTrace();
//		}
		
		
		}

}
