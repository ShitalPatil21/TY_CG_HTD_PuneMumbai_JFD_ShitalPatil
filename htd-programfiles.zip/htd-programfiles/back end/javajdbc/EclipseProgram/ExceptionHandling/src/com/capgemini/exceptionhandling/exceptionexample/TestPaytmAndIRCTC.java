package com.capgemini.exceptionhandling.exceptionexample;

public class TestPaytmAndIRCTC {

	public static void main(String[] args) {
		
		System.out.println("main started");
		
		Paytm p = new Paytm();
		
		//p.book();

		try {
			p.book();
			}
			catch(Exception e )
			{
				System.out.println("Exception handeled in main method");
			}
		
		System.out.println("main ended");

	}

}
