package com.capgemini.mapstudent;

public class StudentPredicate {
	
	String name;
	double percentage;
	public StudentPredicate(String name,double percentage) {
		super();
		this.name=name;
		this.percentage = percentage;
	}
	
	
	

}
