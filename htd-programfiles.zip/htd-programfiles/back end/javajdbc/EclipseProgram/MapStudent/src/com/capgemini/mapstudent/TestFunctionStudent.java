package com.capgemini.mapstudent;

import java.util.function.Function;

public class TestFunctionStudent {

	public static void main(String[] args) {
		
			Function<Integer, FunctionStudent> f =
					i->{
						FunctionStudent s = new FunctionStudent();
						s.ID = i;
						return s;
					};
					
					FunctionStudent s = f.apply(10);
					
					System.out.println("name is = "+s.name);
					System.out.println("ID is = "+s.ID);
					System.out.println("gender is = "+s.gender);
					System.out.println("percentage is = "+s.percentage);
					
	}

}
