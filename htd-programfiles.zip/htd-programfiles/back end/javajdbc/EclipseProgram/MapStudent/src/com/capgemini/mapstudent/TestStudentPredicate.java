package com.capgemini.mapstudent;

import java.util.function.Predicate;

public class TestStudentPredicate {

	public static void main(String[] args) {
		StudentPredicate s1=new StudentPredicate("aishu",39.2);
		
		
		Predicate<StudentPredicate> p  = i->
		{
			if(i.percentage>35)
			{	
				System.out.println("pass student name = "+i.name+"and percentage is = "+i.percentage);
				return true;
				
			}
			else
			{
				System.out.println("fail student name = "+i.name+"and percentage is = "+i.percentage);
				return false;
			}
		};
		
		
		boolean res = p.test(s1);
		System.out.println("result is "+res);
	}	

	}


