package com.capgemini.mapstudent;

import java.util.function.Supplier;

public class TestSupplier {

	public static void main(String[] args) {
		
		Supplier<StudentSupplier> a = () -> new StudentSupplier();
		
		StudentSupplier s =a.get();
		StudentSupplier p = a.get();
		
		System.out.println(s);
		System.out.println(p);
				
	}

}
