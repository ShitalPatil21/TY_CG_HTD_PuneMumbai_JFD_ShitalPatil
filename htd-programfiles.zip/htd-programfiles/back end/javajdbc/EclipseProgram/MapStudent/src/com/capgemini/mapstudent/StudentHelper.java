package com.capgemini.mapstudent;

import java.util.List;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.stream.Collectors;

public class StudentHelper {

//display pass
	
	void displaypass(ArrayList<Student> al) {

		List<Student> li = al.stream().filter(i -> i.Percentage > 35).collect(Collectors.toList());

		Iterator<Student> it = li.iterator();

		System.out.println("************Pass Student****************");

		while (it.hasNext()) {
			Student s = it.next();

			System.out.println("Name = " + s.Name);
			System.out.println("ID = " + s.ID);
			System.out.println("Percentage = " + s.Percentage);
			System.out.println("Gender = " + s.Gender);
			System.out.println("..............................");
		}

	}
	
	
//display fail
	void displayfail(ArrayList<Student> al) {
		List<Student> li = al.stream().filter(i -> i.Percentage < 35).collect(Collectors.toList());
		Iterator<Student> it = li.iterator();
		System.out.println("************Pass Student****************");
		while (it.hasNext()) {
			Student s = it.next();

			System.out.println("Name = " + s.Name);
			System.out.println("ID = " + s.ID);
			System.out.println("Percentage = " + s.Percentage);
			System.out.println("Gender = " + s.Gender);
			System.out.println("..............................");
		}

	}

//display all
	
	void Display(ArrayList<Student> al) {
		Iterator<Student> it = al.iterator();
		System.out.println("*******************All student**********");
		while (it.hasNext()) {
			Student s = it.next();

			System.out.println("Name = " + s.Name);
			System.out.println("ID = " + s.ID);
			System.out.println("Percentage = " + s.Percentage);
			System.out.println("Gender = " + s.Gender);
			System.out.println("..............................");
		}

	}

//display topper
	Comparator<Student> comp = (o1, o2) -> {
		Double i = o1.Percentage;

		Double j = o2.Percentage;

		return i.compareTo(j);

	};

	void DisplayTopper(ArrayList<Student> al) {

		Student s = al.stream().max(comp).get();

		System.out.println("Name = " + s.Name);
		System.out.println("ID = " + s.ID);
		System.out.println("Percentage = " + s.Percentage);
		System.out.println("Gender = " + s.Gender);
		System.out.println("..............................");

	}

//display fail by gender
	void displayfailbygender(ArrayList<Student> al) {
		List<Student> li = al.stream().filter(i -> i.Percentage < 35 && i.Gender == 'F').collect(Collectors.toList());
		Iterator<Student> it = li.iterator();
		System.out.println("************Fail student Student****************");
		while (it.hasNext()) {
			Student s = it.next();

			System.out.println("Name = " + s.Name);
			System.out.println("ID = " + s.ID);
			System.out.println("Percentage = " + s.Percentage);
			System.out.println("Gender = " + s.Gender);
			System.out.println("..............................");
		}

	}

//display pass by gender
	void displaypassbygender(ArrayList<Student> al) {
		List<Student> li = al.stream().filter(i -> i.Percentage > 35 && i.Gender == 'F').collect(Collectors.toList());
		Iterator<Student> it = li.iterator();
		System.out.println("************Fail student Student****************");
		while (it.hasNext()) {
			Student s = it.next();

			System.out.println("Name = " + s.Name);
			System.out.println("ID = " + s.ID);
			System.out.println("Percentage = " + s.Percentage);
			System.out.println("Gender = " + s.Gender);
			System.out.println("..............................");
		}

	}

}
