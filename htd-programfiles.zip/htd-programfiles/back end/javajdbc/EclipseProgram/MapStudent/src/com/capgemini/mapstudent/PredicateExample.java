package com.capgemini.mapstudent;

import java.util.function.Predicate;

public class PredicateExample {
public static void main(String[] args) {
	Predicate<Integer> p  = i->
	{
		if(i%2==0)
		{
			return true;
		}
		else
		{
			return false;
		}
	};
	boolean res = p.test(15);
	System.out.println("result is "+res);
}	
}
