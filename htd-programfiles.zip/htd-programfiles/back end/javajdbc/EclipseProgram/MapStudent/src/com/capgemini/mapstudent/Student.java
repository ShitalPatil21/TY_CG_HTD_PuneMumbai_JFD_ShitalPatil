package com.capgemini.mapstudent;

public class Student {
	String Name;
	int ID;
	double Percentage;
	char Gender;
	public Student(String name, int iD, double percentage, char gender) {
		super();
		Name = name;
		ID = iD;
		Percentage = percentage;
		Gender = gender;
	}
	

}
