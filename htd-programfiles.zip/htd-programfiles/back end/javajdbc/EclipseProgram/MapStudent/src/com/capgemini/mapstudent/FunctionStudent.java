package com.capgemini.mapstudent;

public class FunctionStudent {
	
	int ID;
	String name;
	double percentage;
	char gender;
	
	FunctionStudent()
	{
		
	}

	public FunctionStudent(int iD, String name, double percentage, char gender) {
		super();
		ID = iD;
		this.name = name;
		this.percentage = percentage;
		this.gender = gender;
	}
	

}
