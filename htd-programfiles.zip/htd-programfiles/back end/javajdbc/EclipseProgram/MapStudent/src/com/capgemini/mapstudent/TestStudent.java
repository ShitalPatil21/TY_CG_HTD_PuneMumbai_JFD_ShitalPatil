package com.capgemini.mapstudent;

import java.util.ArrayList;
//import java.util.LinkedHashMap;


public class TestStudent {
	public static void main(String[] args) {

		Student s1 = new Student("aishu", 	1, 	40.45, 'F');
		Student s2 = new Student("hrishi",  2, 	8.45,  'M');
		Student s3 = new Student("ketaki",  3, 	29.45, 'F');
		Student s4 = new Student("amruta",  4, 	75.45, 'F');
		Student s5 = new Student("abhi", 	5, 	95.45, 'M');
		Student s6 = new Student("atharva", 6, 	76.45, 'M');
		Student s7 = new Student("aditi", 	7, 	15.45, 'F');
		Student s8 = new Student("eknath",  8, 	68.45, 'M');
		
		ArrayList<Student> al1 = new ArrayList<Student>();
		al1.add(s1);
		al1.add(s2);
		al1.add(s3);
		al1.add(s4);
		al1.add(s5);
		al1.add(s6);
		al1.add(s7);
		al1.add(s8);
		
		StudentHelper sh = new StudentHelper();
		//sh.Display(al1);
		//sh.displaypass(al1);
		//sh.displayfail(al1);
		//sh.DisplayTopper(al1);
		//sh.displayfailbygender(al1);
		sh.displaypassbygender(al1);
	}

}
