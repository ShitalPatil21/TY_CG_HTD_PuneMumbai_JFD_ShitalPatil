package com.capgemini.mapstudent;

import java.util.function.Function;

public class FunctionExample {

	public static void main(String[] args) {

		
		Function<Integer, Integer> f = i -> i * i;

		int ans = f.apply(5);
		System.out.println("result is = " + ans);

	}

}
