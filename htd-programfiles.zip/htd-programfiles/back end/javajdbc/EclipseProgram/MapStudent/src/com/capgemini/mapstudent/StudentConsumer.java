package com.capgemini.mapstudent;

import java.util.function.Consumer;

public class StudentConsumer {
	public static void main(String[] args) {
		
	
	Consumer<StudentSupplier> c = (s) ->
	{
		System.out.println("Name is"+s.name);
		System.out.println("ID is"+s.ID);
		System.out.println("percentage is"+s.percentage);
	};
	
	StudentSupplier s1 = new StudentSupplier(1,"Divya",78.4,'f');
	c.accept(s1);
	}
}
