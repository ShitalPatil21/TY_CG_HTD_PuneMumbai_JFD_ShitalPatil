package com.capgemini.mapstudent;

public class StudentSupplier {

	int ID;
	String name;
	double percentage;
	char gender;
	
	StudentSupplier()
	{
		
	}

	public StudentSupplier(int iD, String name, double percentage, char gender) {
		super();
		ID = iD;
		this.name = name;
		this.percentage = percentage;
		this.gender = gender;
	}

}
