package com.capgemini.objectclass.objectExample;

public class Employee {

	int ID;
	String Name;
	double Salary;
	char Gender;
	
	
	public Employee(int iD, String name, double salary, char gender) {
		super();
		ID = iD;
		Name = name;
		Salary = salary;
		Gender = gender;
	}


	@Override
	public String toString() {
		return "Employee [ID=" + ID + ", Name=" + Name + ", Salary=" + Salary + ", Gender=" + Gender + "]";
	}
	
	
	
}
