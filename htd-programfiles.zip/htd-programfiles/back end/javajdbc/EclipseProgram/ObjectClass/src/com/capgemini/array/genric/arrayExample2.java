package com.capgemini.array.genric;

public class arrayExample2 {
	public static void main(String[] args) {
		Student [] st= new Student[2];
		Student s1=new Student(1,"aishu",90.0);
		Student s2=new Student(2,"hrishi",70.0);	
		
		st[0] = s1;
		st[1] = s2;
		
		Array(st);
	}
	
	public static void Array(Student [] st)
	{
		for(Student st1:st)
		{
			System.out.println(st1.id);
			System.out.println(st1.name);
			System.out.println(st1.percentage);
		}
	}

}
