
package com.capgemini.array.genric;

//import java.util.Scanner;

public class ArrayExample1 {

	public static void main(String[] args) {
		/*
		 * Scanner sc = new Scanner(System.in);
		 * System.out.println("Enter the size of array"); int size = sc.nextInt();
		 * System.out.println("Enter the element in array"); int[] d = new int[size];
		 * char [] c=new char[size]; for (int i = 0; i < size; i++) { d[i] =
		 * sc.nextInt(); } System.out.println("list of element of array"); for (int i =
		 * 0; i < size; i++) { System.out.println(d[i]); }
		 * System.out.println("Enter the character"); for (int i = 0; i < size; i++) {
		 * c[i] = sc.next().charAt(0); }
		 * 
		 * System.out.println("list of element of character array"); for (int i = 0; i <
		 * size; i++) { System.out.println(c[i]); }
		 */

		/*
		 * char []ch1= {'a','i','s','h'}; for (char c1:ch1) { System.out.println(c1); }
		 */

		//
//		double [] d=new double[2];
//		d[0]=2.4;
//		d[1]=6.4;
		

		int []a=ADD();
		System.out.println("from main method");
		for (int a1 : a) {
			System.out.println(a1);
		}

		
		
	}

	public static int[] ADD() {
		System.out.println("from add method");
		int[] a = new int[4];
		a[0] = 1;
		a[1] = 1;
		a[2] = 1;
		a[3] = 1;
		return a;
	}

}
