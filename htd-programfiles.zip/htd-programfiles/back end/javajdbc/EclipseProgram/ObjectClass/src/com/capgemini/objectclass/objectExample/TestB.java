package com.capgemini.objectclass.objectExample;

public class TestB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Student s=new Student(1,"hrishi",85);
			System.out.println(s);
			
			Student s1=new Student(1,"aishu",85);
			System.out.println(s1);
	}

}
