package com.capgemini.objectclass.objectExample;

public class Cow {

	int ID;
	String name;
	
	public boolean equals(Object ref)
	{
		Cow r=(Cow)ref;
		if(this.ID == r.ID)
		{
			if(this.name == r.name)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
		
	}
}
