package com.capgemini.objectclass.objectExample;

public class TestG {
	
	public static void main(String [] args)
	{
		Product c =new Product();
		c.id=1;
		c.name="pen";
		c.type="blue pen";
		c.cost=50;
		c.brand="Lexi";
		
		
		Product e =new Product();
		e.id=1;
		e.name="pencile";
		e.type="black pencile";
		e.cost=80;
		e.brand="Classmate";

		Product d =new Product();
		d.id=1;
		d.name="pen";
		d.type="blue pen";
		d.cost=50;
		d.brand="Lexi";
		
		
		System.out.println(c.equals(d));
	}

}
