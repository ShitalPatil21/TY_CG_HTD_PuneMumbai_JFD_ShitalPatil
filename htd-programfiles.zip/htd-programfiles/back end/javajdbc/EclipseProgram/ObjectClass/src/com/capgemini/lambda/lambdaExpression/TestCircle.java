package com.capgemini.lambda.lambdaExpression;

public class TestCircle {
public static void main(String[] args) {
	Circle c= (p,r) -> p*r*r;
	double c1=c.areaofcircle(3.14, 10);
	System.out.println(c1);
}
	
}
