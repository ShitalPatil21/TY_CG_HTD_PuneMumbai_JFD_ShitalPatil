package com.capgemini.objectclass.objectExample;

public class TestC {
	
	public static void main(String[] args) {
		Employee e=new Employee(1,"Aishu",2000,'F');
		System.out.println(e);
	}

}
