package com.capgemini.lambda.lambdaExpression;

interface lambda{
	int sqr(int a);
}

public class LambdaExample2 {
	public static void main(String[] args) {
		lambda s = a -> a*a;
		int j= s.sqr(10);
		System.out.println("square of a = "+j);
	}

}
