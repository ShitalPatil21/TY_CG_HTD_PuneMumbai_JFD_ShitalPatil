
package com.capgemini.objectclass.objectExample;

public class Remote {
	
	int id;
	String name;
	public Remote(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	

}
