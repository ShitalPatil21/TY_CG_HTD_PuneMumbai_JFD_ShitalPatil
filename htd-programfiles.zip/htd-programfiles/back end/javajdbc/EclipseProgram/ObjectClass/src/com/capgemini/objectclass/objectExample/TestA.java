package com.capgemini.objectclass.objectExample;

public class TestA {
	
	public static void main(String [] args ) {
		
	}

}
