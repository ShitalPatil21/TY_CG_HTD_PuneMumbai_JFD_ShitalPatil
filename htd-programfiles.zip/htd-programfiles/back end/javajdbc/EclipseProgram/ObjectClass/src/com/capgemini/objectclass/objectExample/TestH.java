package com.capgemini.objectclass.objectExample;

public class TestH {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

		Remote r = new Remote(1,"abc");
		
		System.out.println(r.id);
		System.out.println(r.name);
		
		//Class c = r.getClass();
		
		//Object k=c.newInstance();
		
		//Remote e =(Remote)k;
		
		
	}

}
