package com.capgemini.array.genric;

public class TestMouse {
	
	public static void main(String[] args) {
		
		Mouse m = new Mouse();
		
		System.out.println("double type of array");
		
		double[] d = {1.2,3.5,6.6};
				
		m.walk(d);
		
		System.out.println("int type of array");
		
		int[] i = {1,3,6};
		
		m.run(i);
		
		System.out.println("odd no of int type of array");
		
		m.oddno(i);
		
	}

}
