package com.capgemini.lambda.lambdaExpression;

public interface Circle {

	double areaofcircle(double p,int r);
}
