package com.capgemini.objectclass.objectExample;

public class TestI {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub

			Marker m = new Marker("abc",1);
			
			System.out.println("ID"+m.id);
			System.out.println("name"+m.name);
			
			
			System.out.println(".....................");
			Object r = m.clone();
			Marker k = (Marker)r;
			
			System.out.println("ID"+k.id);
			System.out.println("name"+k.name);
	}

}
