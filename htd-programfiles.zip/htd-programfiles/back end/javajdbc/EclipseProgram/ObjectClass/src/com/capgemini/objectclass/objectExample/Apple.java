package com.capgemini.objectclass.objectExample;

public class Apple {
	

}
