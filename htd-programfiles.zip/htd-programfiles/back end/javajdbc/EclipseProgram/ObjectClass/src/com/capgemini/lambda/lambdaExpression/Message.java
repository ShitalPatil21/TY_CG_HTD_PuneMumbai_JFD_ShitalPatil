package com.capgemini.lambda.lambdaExpression;

public interface Message {
	
	void gm();

}
