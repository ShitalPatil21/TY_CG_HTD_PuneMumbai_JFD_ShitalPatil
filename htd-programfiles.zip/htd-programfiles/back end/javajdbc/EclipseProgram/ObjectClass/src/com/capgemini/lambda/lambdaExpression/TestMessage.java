package com.capgemini.lambda.lambdaExpression;

public class TestMessage {
public static void main(String[] args) {
	Message m = () ->System.out.println("very gm");
	m.gm();
}
}
