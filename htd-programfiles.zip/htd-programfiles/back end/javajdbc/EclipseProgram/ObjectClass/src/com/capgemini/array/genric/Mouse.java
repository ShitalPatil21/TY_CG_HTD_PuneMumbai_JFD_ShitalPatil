package com.capgemini.array.genric;

public class Mouse {
	
	void walk(double[]a)
	{
		for (double d:a)
		{	
			
			System.out.println(d);
		}
	}
	
	void run(int[]a)
	{

		for (double i:a)
		{	
			
			System.out.println(i);
		}
	}
	
	void oddno(int []a)
	{
		for (int o:a)
		{
			if(o%2==1)
			{
			System.out.println(o);
			}
		}
	}

}
