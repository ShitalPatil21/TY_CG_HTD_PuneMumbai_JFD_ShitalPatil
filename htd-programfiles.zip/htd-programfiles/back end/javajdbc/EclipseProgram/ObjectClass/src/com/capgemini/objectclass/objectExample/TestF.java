package com.capgemini.objectclass.objectExample;

public class TestF {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Cow c =new Cow();
		c.ID=1;
		c.name="Aishu";
		
		Cow e =new Cow();
		e.ID=2;
		e.name="Hrishi";

		Cow d =new Cow();
		d.ID=1;
		d.name="Aishu";
		
		
		System.out.println(c.equals(d));
	}

}
