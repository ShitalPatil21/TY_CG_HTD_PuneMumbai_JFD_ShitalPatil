package com.capg.modifiers.family;

public class father {
	
	private void ATM()
	{
		System.out.println("Access ATM");
	}
	
	void Car()
	{
		System.out.println("Access Car");
	}
	
	protected void Bike()
	{
		System.out.println("Access Bike");
	}
	
	public void cycle()
	{
		System.out.println("Access cycle");
	}

}
