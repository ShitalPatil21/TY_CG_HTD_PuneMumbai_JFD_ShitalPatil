package com.capg.modifiers.family;

public class son {

	father f=new father();
	
	
	
}
