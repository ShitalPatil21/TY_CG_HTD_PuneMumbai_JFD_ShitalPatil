package com.capgemini.JDBC.controller;

import java.util.Scanner;

import com.capgemini.JDBC.beans.UserBean;
import com.capgemini.dao.UserDAO;
import com.capgemini.dao.UserFactory;

public class GetInfo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		//UserDAO dao = UserFactory.getInstance();
		UserDAO dao = UserFactory.getInstance();
		
//		System.out.println("Enter the user id : ");
//		UserBean user = dao.getInfo(sc.nextInt());
		
		System.out.println("enter password");
		UserBean password = dao.getpassword(sc.nextLine());
		
//		if(user!=null) {
//			System.out.println(user);
//		}
//		else {
//			System.out.println("Something went wrong ");
//		}
//		
		if(password!=null) {
			System.out.println(password);
		}
		else {
			System.out.println("Something went wrong ");
		}
		sc.close();
	}

}
