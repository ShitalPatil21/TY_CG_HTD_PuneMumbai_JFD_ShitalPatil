package com.capgemini.dao;

import com.capgemini.dao.UserDaoClass;
public class UserFactory {
	
	private UserFactory()
	{
		
	}

	public static UserDAO getInstance() {
		UserDAO dao = new UserDaoClass();
		return dao;
	}
}

