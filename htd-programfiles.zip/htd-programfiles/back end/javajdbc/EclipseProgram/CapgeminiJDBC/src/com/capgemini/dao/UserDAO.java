package com.capgemini.dao;

import java.util.List;

import com.capgemini.JDBC.beans.UserBean;

public interface UserDAO {

	//public List<UserBean> getAllInfo();

	//public UserBean getInfo(int userid);

	public UserBean getpassword(String  password);
	

}
