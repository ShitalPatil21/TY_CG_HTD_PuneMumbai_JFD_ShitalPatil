package com.capgemini.dao;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import com.capgemini.JDBC.beans.UserBean;

public class UserDaoClass implements UserDAO {

	FileReader reader = null;
	Properties prop = null;
	UserBean user = null;

	public UserDaoClass() {

		try {
			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);
			Class.forName(prop.getProperty("driverClass"));
			System.out.println("Driver Loaded...");
			System.out.println("*************************");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

//	@Override
//	public UserBean getInfo(int userid) {
//		try (Connection conn = DriverManager.getConnection(prop.getProperty("dburl"), prop.getProperty("user"),
//				prop.getProperty("password"));
//				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query1"))) {
//
//			pstmt.setInt(1, userid);
//
//			try (ResultSet rs = pstmt.executeQuery()) {
//				if (rs.next()) {
//					user = new UserBean();
//					user.setUserid(rs.getInt(1));
//					user.setUsername(rs.getString(2));
//					user.setEmail(rs.getString(3));
//				}
//				return user;
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//
//			//
//			// stmt = conn.createStatement();
//			// rs = stmt.executeQuery(prop.getProperty("query"));
//			// while (rs.next())
//			// {
//			// System.out.println("user Id : " + rs.getInt(1));
//			// System.out.println("user name : " + rs.getString("username"));
//			// System.out.println("Email : " + rs.getString(3));
//			// System.out.println("Password : " + rs.getString("password"));
//			// System.out.println("************************");
//			// }
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return null;
//	}

	@Override
	public UserBean getpassword(String password) {
		try (Connection conn = DriverManager.getConnection(prop.getProperty("dburl"), prop.getProperty("user"),
				prop.getProperty("password"));
				PreparedStatement pstmt = conn.prepareStatement(prop.getProperty("query1"))) {

			pstmt.setString(1, password);

			try (ResultSet rs = pstmt.executeQuery()) {
				if (rs.next()) {
					user = new UserBean();
					user.setUserid(rs.getInt(1));
					user.setUsername(rs.getString(2));
					user.setEmail(rs.getString(3));
					user.setPassword(rs.getString(4));
				}
				return user;
			} catch (Exception e) {
				e.printStackTrace();
			}

			//
			// stmt = conn.createStatement();
			// rs = stmt.executeQuery(prop.getProperty("query"));
			// while (rs.next())
			// {
			// System.out.println("user Id : " + rs.getInt(1));
			// System.out.println("user name : " + rs.getString("username"));
			// System.out.println("Email : " + rs.getString(3));
			// System.out.println("Password : " + rs.getString("password"));
			// System.out.println("************************");
			// }

		} catch (Exception e) {
			e.printStackTrace();
		}

		
		return null;
	}

}
