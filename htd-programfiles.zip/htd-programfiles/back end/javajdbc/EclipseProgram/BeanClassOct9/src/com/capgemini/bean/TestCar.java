package com.capgemini.bean;

public class TestCar {

	public static void main(String[] args) {
		Car c = new Car(1,"Aishu");
		 
		
		System.out.println("Name is = "+c.getName());
		System.out.println("Cost is = "+c.getCost());
		
	}

}
