package com.capgemini.bean;

public class DatabaseEmployee {
	
	void reciver(Employee e)
	{
		System.out.println(".......I am Data Base");
		System.out.println("Name  =  "+e.getName());
		System.out.println("ID  =  "+e.getId());
		System.out.println("Salary  =  "+e.getSalay());
		System.out.println("Role  =  "+e.getRole());
		System.out.println("Department  =  "+e.getDepartment());
	}


}
