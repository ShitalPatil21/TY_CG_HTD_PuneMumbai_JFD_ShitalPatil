package com.capgemini.bean;

public class TestEmployee {

	public static void main(String[] args) {

	}

}
