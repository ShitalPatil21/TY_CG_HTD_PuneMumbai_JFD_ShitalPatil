package com.capgemini.bean;

public class Student {
	
		private int id;
		private String name;
		private double height;
		
		//get set for ID
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		
		//get set for Name
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		//get set for Height
		public double getHeight() {
			return height;
		}
		public void setHeight(double height) {
			this.height = height;
		}
		
		
		
}
