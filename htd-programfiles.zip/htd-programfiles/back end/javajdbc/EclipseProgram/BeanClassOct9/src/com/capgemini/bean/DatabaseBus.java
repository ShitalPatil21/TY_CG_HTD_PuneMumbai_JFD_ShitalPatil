package com.capgemini.bean;

public class DatabaseBus {
	
	void recive(Bus b)
	{
		System.out.println(".....I am DATA BASE.....");
		System.out.println("Name = "+b.getName());
		System.out.println("Name = "+b.getSeats());
	}

}
