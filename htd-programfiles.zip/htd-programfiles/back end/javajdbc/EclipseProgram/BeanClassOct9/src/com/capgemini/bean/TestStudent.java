package com.capgemini.bean;

public class TestStudent {

	public static void main(String[] args) {
		Student s = new Student();
		s.setName("Aishwarya");
		s.setId(1);
		s.setHeight(5.6);
		DatabaseStudent dbs=new DatabaseStudent();
		dbs.reciver(s);
	}

}
