package com.capgemini.bean;

public class DatabaseStudent {
	
	void reciver(Student t)
	{
		System.out.println(".......I am Data Base");
		System.out.println("Name  =  "+t.getName());
		System.out.println("ID  =  "+t.getId());
		System.out.println("Height  =  "+t.getHeight());
	}

}
