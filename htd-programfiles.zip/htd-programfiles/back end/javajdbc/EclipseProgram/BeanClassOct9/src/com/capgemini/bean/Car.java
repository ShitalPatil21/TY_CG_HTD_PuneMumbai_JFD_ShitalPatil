package com.capgemini.bean;

public class Car {
	
	private int cost;
	private String name;
	
	//get for cost
	public int getCost() {
		return cost;
	}
	
	//get for name
	public String getName() {
		return name;
	}

	public Car(int cost, String name) {
		super();
		this.cost = cost;
		this.name = name;
	}
	
	
	

}
