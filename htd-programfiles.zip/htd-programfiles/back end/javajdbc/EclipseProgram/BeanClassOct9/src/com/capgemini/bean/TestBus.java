package com.capgemini.bean;

public class TestBus {

	public static void main(String[] args) {
		
		Bus b = new Bus("aaa",5);
		
		DatabaseBus dbb=new DatabaseBus();
		dbb.recive(b);
		
	}
		
}
