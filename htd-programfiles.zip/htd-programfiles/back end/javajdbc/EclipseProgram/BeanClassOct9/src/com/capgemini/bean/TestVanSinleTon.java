package com.capgemini.bean;

public class TestVanSinleTon {

	public static void main(String[] args) {
		
		VanSingleTon r = VanSingleTon.getVanSingleTon();
		
		System.out.println(r);
		
		VanSingleTon t = VanSingleTon.getVanSingleTon();
		
		System.out.println(t);
		
		
	}

}
