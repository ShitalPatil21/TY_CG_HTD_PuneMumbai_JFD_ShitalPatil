package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;
import java.util.Iterator;

public class TestArrayList5 {
	public static void main(String[] args) {
		ArrayList<Double> al = new ArrayList<Double>();
		al.add(81.5);
		al.add(83.5);
		
		for(int i =0;i<2;i++)
		{
		Double r = al.get(i);
		//Object r = al.get(i);
		System.out.println(r);
		}
	}

}
