package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;

public class TestArrayList {

	public static void main(String[] args) {
		
		ArrayList al =new ArrayList();
		al.add(24);
		al.add("chinu");
		al.add(9.9);
		al.add('A');
		
//		Object r = al.get(0);
//		System.out.println(r);
//		
//		Object t = al.get(1);
//		System.out.println(t);
//		
//		
//		Object p = al.get(2);
//		System.out.println(p);
//		
//		
//		Object q = al.get(3);
//		System.out.println(q);
		
		
//		
//		for (int i=0;i<4;i++)
//		{
//			Object r = al.get(i);
//			System.out.println(r);
//		}
		
		
		for(Object r:al)
		{
			System.out.println(r);
		}
	}

}
