package com.capgemini.collectionframweork.ArrayList;

public class EmployeeExample {
	
	int ID;
	String name;
	double percentage;

	EmployeeExample(int ID,String Name,double percentage)
	{
		this.ID = ID;
		this.name = Name;
		this.percentage = percentage;
		
	}
	
	

}
