package com.capgemini.collectionframweork.ArrayList;

public class Student {
	
	int ID;
	String name;
	double percentage;

	Student(int ID,String Name,double percentage)
	{
		this.ID = ID;
		this.name = Name;
		this.percentage = percentage;
		
	}
	
	 void display()
	{
		System.out.println("name = "+name);
		System.out.println("name = "+ID);
		System.out.println("name = "+percentage);
	}

}
