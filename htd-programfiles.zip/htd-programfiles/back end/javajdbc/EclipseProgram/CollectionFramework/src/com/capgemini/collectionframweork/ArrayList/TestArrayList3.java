package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;
import java.util.ListIterator;

public class TestArrayList3 {
public static void main(String[] args) {
		
		ArrayList al =new ArrayList();
		al.add(24);
		al.add("chinu");
		al.add(9.9);
		al.add('A');
		
		ListIterator m = al.listIterator();
		while(m.hasNext())
		{
			Object r = m.next();
			System.out.println(r);
		
		}
}


}
