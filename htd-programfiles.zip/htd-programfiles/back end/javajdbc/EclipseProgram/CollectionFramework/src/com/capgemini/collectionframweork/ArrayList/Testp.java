package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;

public class Testp {

	public static void main(String[] args) {
		
		ArrayList<Double> al =new ArrayList<Double>();
		al.add(1.1);
		al.add(2.2);
		al.add(3.3);
		al.add(4.4);
		
		System.out.println("Before------>"+al);
		
		//al.add(1,5.4);
		//al.add(9,8.4);  //exception	//add //AIOBI
	
		
		//al.set(3, 5.5);
		
		System.out.println("After---------->"+al);
		
	}

}
