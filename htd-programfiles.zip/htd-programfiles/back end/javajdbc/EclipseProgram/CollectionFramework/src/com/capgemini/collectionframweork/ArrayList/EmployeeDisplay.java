package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;

public class EmployeeDisplay {
	
	
	 void display(ArrayList<EmployeeExample> al)
	 {
	 for(EmployeeExample e :al)
		{
		 	if(e.percentage>60)
		 	{
		 		 System.out.println("Employee name = "+e.name);
					System.out.println("Employee ID = "+e.ID);
					System.out.println("Employee Percentage = "+e.percentage);
					System.out.println("....................");
		 	}
		}

	 }
	 
	
}
