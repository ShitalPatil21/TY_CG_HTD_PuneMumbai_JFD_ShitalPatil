package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;
import java.util.Iterator;

public class TestArrayList2 {
		public static void main(String[] args) {
		
		ArrayList al =new ArrayList();
		al.add(24);
		al.add("chinu");
		al.add(9.9);
		al.add('A');
		
		Iterator it = al.iterator();
//		Object a = it.next();
//		Object b = it.next();
//		Object c = it.next();
//		Object d = it.next();
//		//Object e = it.next();
//		
//		System.out.println(a);
//		System.out.println(b);
//		System.out.println(c);
//		System.out.println(d);
		
		while(it.hasNext())
		{
			Object r = it.next();
			System.out.println(r);
		}
		
		
}

}
