package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;

public class TestArrayList6 {
	public static void main(String[] args) {
		ArrayList <Double>al =new ArrayList<Double>();
		al.add(24.2);
		al.add(22.5);
		al.add(9.9);
		al.add(5.5);
		
		for(Double r:al)
		{
			System.out.println(r);
		}
	}

}
