package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;

public class TestStudent {

	public static void main(String[] args) {

		ArrayList<Student> al =new ArrayList<Student>();
		
		Student s1 = new Student(1,"Aishu",5.6);
		Student s2 = new Student(1,"Hrishi",5.6);
	
		al.add(s1);
		al.add(s2);
		
		for(int i=0;i<2;i++)
		{
			Student r = al.get(i);
			
			System.out.println(r);
				
		}
		s1.display();
		s2.display();
	
	}

}
