package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;
import java.util.ListIterator;

public class TestIteratorExample {
public static void main(String[] args) {
		
		ArrayList al =new ArrayList();
		al.add(24);
		al.add("chinu");
		al.add(9.9);
		al.add('A');
		
		ListIterator m = al.listIterator();
		System.out.println("-------->forword");
		while(m.hasNext())
		{
			Object r = m.next();
			System.out.println(r);
		}
		
		System.out.println("<---------Backward");
		while(m.hasPrevious())
		{
			Object r=m.previous();
			System.out.println(r);
		}
}

}
