package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;

public class TestIteratorExample2 {

	public static void main(String[] args) {
		ArrayList al =new ArrayList();
		al.add(24);
		al.add("chinu");
		al.add(9.9);
		al.add('A');
		
		System.out.println(al);
	}

}
