package com.capgemini.collectionframweork.ArrayList;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListExample2 {
	public static void main(String[] args) {
		LinkedList al =new LinkedList();
		al.add(5);
		al.add("hrishi");
		al.add(5.0);
		
		
		System.out.println("........for loop........");
		for (int i=0;i<3;i++)
			{
			Object r = al.get(i);
				System.out.println(r);
			}
			
		System.out.println("........for each........");
		for(Object r:al)
		{
			System.out.println(r);
		}
		
		System.out.println("........Iterator........");
		Iterator it = al.iterator();
		while(it.hasNext())
		{
			Object r = it.next();
			System.out.println(r);
		}
		
		System.out.println("........ListIterator........");
		ListIterator m = al.listIterator();
		System.out.println("-------->forword");
		while(m.hasNext())
		{
			Object r = m.next();
			System.out.println(r);
		}
		
		System.out.println("<---------Backward");
		while(m.hasPrevious())
		{
			Object r=m.previous();
			System.out.println(r);
		}


	}

}
