package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;

public class EmployeeArrayList {

	public static void main(String[] args) {


		ArrayList<EmployeeExample> al =new ArrayList<EmployeeExample>();
		
		EmployeeExample s1 = new EmployeeExample(1,"Aishu",60.5);
		EmployeeExample s2 = new EmployeeExample(1,"Hrishi",50.6);
		EmployeeExample s3 = new EmployeeExample(1,"Ketaki",70.5);
		EmployeeExample s4 = new EmployeeExample(1,"Abhi",45.5);
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		EmployeeDisplay ed = new EmployeeDisplay();
		ed.display(al);
		
	}

}