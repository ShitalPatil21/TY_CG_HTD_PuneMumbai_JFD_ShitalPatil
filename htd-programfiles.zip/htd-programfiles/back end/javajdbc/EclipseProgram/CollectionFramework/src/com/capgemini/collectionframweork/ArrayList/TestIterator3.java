package com.capgemini.collectionframweork.ArrayList;

import java.util.ArrayList;
import java.util.ListIterator;

public class TestIterator3 {
	
	public static void main(String[] args) {
		ArrayList <Double>al =new ArrayList<Double>();
		al.add(24.2);
		al.add(22.5);
		al.add(9.9);
		al.add(5.5);
		
		ListIterator <Double> it = al.listIterator();
		while(it.hasNext())
		{
			Double r = it.next();
			System.out.println(r);
		}
		System.out.println("...........................");
		while(it.hasPrevious())
		{
			Double r = it.previous();
			System.out.println(r);
		}
	}

}
