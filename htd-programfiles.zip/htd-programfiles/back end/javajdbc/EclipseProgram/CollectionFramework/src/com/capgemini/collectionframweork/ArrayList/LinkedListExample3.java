package com.capgemini.collectionframweork.ArrayList;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListExample3 {

	public static void main(String[] args) {
		LinkedList<Character> al =new LinkedList<Character>();
		al.add('A');
		al.add('B');
		al.add('C');
		
		
		System.out.println("........for loop........");
		for (int i=0;i<3;i++)
			{
			Character r = al.get(i);
				System.out.println(r);
			}
			
		System.out.println("........for each........");
		for(Character r:al)
		{
			System.out.println(r);
		}
		
		System.out.println("........Iterator........");
		Iterator<Character> it = al.iterator();
		while(it.hasNext())
		{
			Character r = it.next();
			System.out.println(r);
		}
		
		System.out.println("........ListIterator........");
		ListIterator <Character>m = al.listIterator();
		System.out.println("-------->forword");
		while(m.hasNext())
		{
			Character r = m.next();
			System.out.println(r);
		}
		
		System.out.println("<---------Backward");
		while(m.hasPrevious())
		{
			Character r=m.previous();
			System.out.println(r);
		}


	}
}
