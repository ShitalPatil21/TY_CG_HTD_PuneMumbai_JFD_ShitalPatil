package com.capgemini.collectionframweork.ArrayList;


import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListexample {
	public static void main(String[] args) {
		
		LinkedList<String> al =new LinkedList<String>();
	al.add("aishu");
	al.add("hrishi");
	al.add("ketaki");
	
	
	System.out.println("........for loop........");
	for (int i=0;i<3;i++)
		{
		String r = al.get(i);
			System.out.println(r);
		}
		
	System.out.println("........for each........");
	for(String r:al)
	{
		System.out.println(r);
	}
	
	System.out.println("........Iterator........");
	Iterator <String>it = al.iterator();
	while(it.hasNext())
	{
		String r = it.next();
		System.out.println(r);
	}
	
	System.out.println("........ListIterator........");
	ListIterator <String>m = al.listIterator();
	System.out.println("-------->forword");
	while(m.hasNext())
	{
		String r = m.next();
		System.out.println(r);
	}
	
	System.out.println("<---------Backward");
	while(m.hasPrevious())
	{
		String r=m.previous();
		System.out.println(r);
	}

}
}
