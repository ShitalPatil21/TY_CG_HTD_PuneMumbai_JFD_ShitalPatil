package com.capgemini.thread.pvrExample;

public class TestPaytmPVR {
	public static void main(String[] args) {
		
		PVR a = new PVR();
		
		Paytm t1 = new Paytm(a);
		
		Paytm t2 = new Paytm(a);
		
		t1.start();
	
		t2.start();
		
		
		
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			// TODO: handle exception
		}
		a.leaveme();
	}

}
