package com.capgemini.thread;

public class TestPen {

	public static void main(String[] args) {
		
		System.out.println("Main Start");
		Pen p = new Pen();
		
		p.start();
		//p.run();
		//in this way also we can call 
		//but we can't access the thread effect
		
		
//		try 
//		{
//			p.join();
//			//p.sleep(1000);
//		} 
//		catch (InterruptedException e) 
//		{
//			e.printStackTrace();
//		}
		
		Pen t = new Pen();
		t.start();
		//t.run();
		
		try 
		{
			t.join();
			//t.sleep(1000);
		} 
		catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
		
		System.out.println("Main Ends");
		
	}

}
