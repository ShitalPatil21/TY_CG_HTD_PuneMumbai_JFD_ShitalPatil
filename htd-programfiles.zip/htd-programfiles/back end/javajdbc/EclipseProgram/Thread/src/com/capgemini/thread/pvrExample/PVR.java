package com.capgemini.thread.pvrExample;

public class PVR {
	
	//synchronized means one by one thread execute 
	//it makes method as thread safe
	synchronized void confirm()
	{
		for(int i =1;i<=5;i++)
		{
			System.out.println(i);
			
			try 
			{
				wait();
				Thread.sleep(1000);
			} 
			catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
	
	synchronized void leaveme()
	{
		notifyAll();
		System.out.println("notify");
	}
}
