package com.capgemini.sortstudent.studentinfo;

public class Employee implements Comparable<Employee>{
	
		int ID;
		String Name;
		Double Salary;
		
		public Employee(int iD, String name, Double salary) {
			super();
			this.ID = iD;
			this.Name = name;
			this.Salary = salary;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ID;
			result = prime * result + ((Name == null) ? 0 : Name.hashCode());
			result = prime * result + ((Salary == null) ? 0 : Salary.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Employee other = (Employee) obj;
			if (ID != other.ID)
				return false;
			if (Name == null) {
				if (other.Name != null)
					return false;
			} else if (!Name.equals(other.Name))
				return false;
			if (Salary == null) {
				if (other.Salary != null)
					return false;
			} else if (!Salary.equals(other.Salary))
				return false;
			return true;
		}

		@Override
		public int compareTo(Employee o) {
			if(this.ID<o.ID) { return 1; } else if(this.ID>o.ID) { return -1; } else {
				  return 0;
		}
		
	
		}		
		
}
