package com.capgemini.sortstudent.studentinfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;


public class StudentDisplay {

	public static void main(String[] args) {

		ArrayList<StudentInfo> al =new ArrayList<StudentInfo>();
		
		StudentInfo s1 = new StudentInfo(1,"Aishu",5.6);
		StudentInfo s2 = new StudentInfo(5,"Hrishi",5.6);
		StudentInfo s3 = new StudentInfo(2,"Ketaki",8.5);
		StudentInfo s4 = new StudentInfo(4,"Abhi",2.6);
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
	
		Collections.sort(al);
		Iterator <StudentInfo> it = al.iterator();
		
		
		 while(it.hasNext())
			{
			 StudentInfo r =it.next();
				System.out.println("name = "+r.name);
				System.out.println("ID = "+r.ID);
				System.out.println("Percentage = "+r.percentage);
			 	
			 
			}

	}
}
