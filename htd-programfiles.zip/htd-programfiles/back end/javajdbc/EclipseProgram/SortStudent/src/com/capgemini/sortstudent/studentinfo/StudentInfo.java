package com.capgemini.sortstudent.studentinfo;

public class StudentInfo implements Comparable<StudentInfo> {

	
	int ID;
	String name;
	double percentage;

	StudentInfo(int ID,String Name,double percentage)
	{
		this.ID = ID;
		this.name = Name;
		this.percentage = percentage;
		
	}
	//logis to sort the student by name in ascending order
	/*
	 * @Override public int compareTo(StudentInfo o) {
	 * 
	 * return this.name.compareTo(o.name); }
	 */

	@Override
	public int compareTo(StudentInfo o) {
		Double k=this.percentage;
		Double t=o.percentage;
		
		return k.compareTo(t);
	}
	
	//logis to sort the student by name in descending order
	/*
	 * @Override public int compareTo(StudentInfo o) {
	 * 
	 * return this.name.compareTo(o.name) * -1; }
	 */
	
	
	
	

	/*
	 * @Override public int compareTo(StudentInfo o) {
	 * if(this.percentage<o.percentage) { return 1; } else
	 * if(this.percentage>o.percentage) { return -1; } else {
	 * 
	 * 
	 * return 0; }
	 * 
	 * 
	 * }
	 */

	/*
	 * @Override public int compareTo(StudentInfo o) {
	 * 
	 * if(this.ID<o.ID) { return 1; } else if(this.ID>o.ID) { return -1; } else {
	 * return 0; } }
	 */
	
	
	
	
	
//	
//	@Override
//	public int compareTo(StudentInfo o) {
//		
//		String k = this.name;
//		String t = o.name;
//		
//		int res = k.compareTo(t);
//		
//		return res;
//	}
//
	
	
}
