package com.capgemini.sortstudent.studentinfo;

import java.util.HashSet;

public class TestG {

	public static void main(String[] args) {
		
			HashSet hs = new HashSet();
			hs.add(15);
			hs.add('A');
			
			hs.add(null);
			
			for(Object r : hs)
			{
				System.out.println(r);
			}
	}

}
