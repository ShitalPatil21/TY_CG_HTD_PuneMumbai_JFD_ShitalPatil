package com.capgemini.sortstudent.studentinfo;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class TestNongenricLinked {
public static void main(String[] args) {
		
		LinkedHashSet hs = new LinkedHashSet();
		hs.add("aish");
		hs.add(1);
		hs.add(90.5);
		hs.add('a');
		hs.add(null);
		
		System.out.println(".........using for each..........");
		for(Object r :hs)
		{
			System.out.println(r);
		}
		
		System.out.println("........using iterator...........");
		Iterator it = hs.iterator();
		while(it.hasNext())
		{
			Object r = it.next();
			System.out.println(r);
		}
	}
		

}
