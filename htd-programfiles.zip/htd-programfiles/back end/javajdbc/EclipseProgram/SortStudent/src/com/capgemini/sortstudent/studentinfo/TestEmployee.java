package com.capgemini.sortstudent.studentinfo;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class TestEmployee {
	public static void main(String[] args) {
		HashSet <Employee>hs = new HashSet <Employee>();
		LinkedHashSet  <Employee>lhs=new LinkedHashSet <Employee>();
		Employee e1 = new Employee(1,"Aishwarya",88888.8);
		Employee e2 = new Employee(2,"Hrishikesh",9.8);
		Employee e3 = new Employee(3,"Ketaki",56.8);
		Employee e4 = new Employee(4,"Abhishek",1.8);
		Employee e5 = new Employee(5,"Akshaya",11.8);
		Employee e6 = new Employee(4,"Abhishek",1.8);
		Employee e7 = new Employee(2,"Hrishikesh",9.8);	
		
		hs.add(e1);
		hs.add(e2);
		hs.add(e3);
		hs.add(e4);
		hs.add(e5);
		hs.add(e6);
		hs.add(e7);
		

		System.out.println(".........using HashSet..........");
		Iterator <Employee> it = hs.iterator();
		while(it.hasNext())
		{
			Employee e = it.next();
			System.out.println("Name = "+e.Name);
			System.out.println("ID = "+e.ID);
			System.out.println("Salary = "+e.Salary);
			System.out.println("......................");
		}
		
		
		
		lhs.add(e1);
		lhs.add(e2);
		lhs.add(e3);
		lhs.add(e4);
		lhs.add(e5);
		

		System.out.println(".........using LinkedHashSet..........");
		Iterator <Employee> it1 = hs.iterator();
		while(it1.hasNext())
		{
			Employee e = it1.next();
			System.out.println("Name = "+e.Name);
			System.out.println("ID = "+e.ID);
			System.out.println("Salary = "+e.Salary);
			System.out.println("......................");
		}
		
		
	}

}
