package com.capgemini.sortstudent.studentinfo;

import java.util.HashSet;
import java.util.Iterator;

public class TestStringHashset {
	public static void main(String[] args) {
		
		HashSet <String>hs = new HashSet<String>();
		hs.add("aish");
		hs.add("komal");
		hs.add("priya");
		hs.add("deepa");
		
		System.out.println(".........using for each..........");
		for(String r :hs)
		{
			System.out.println(r);
		}
		
		System.out.println("........using iterator...........");
		Iterator <String>it = hs.iterator();
		while(it.hasNext())
		{
			String r = it.next();
			System.out.println(r);
		}
	}
		
	}


