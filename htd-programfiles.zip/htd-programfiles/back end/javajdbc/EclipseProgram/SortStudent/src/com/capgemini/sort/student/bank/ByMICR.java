package com.capgemini.sort.student.bank;

import java.util.Comparator;

public class ByMICR implements Comparator<Bank>{

	@Override
	public int compare(Bank o1, Bank o2) {
		Long k=o1.MICR;
		Long p=o2.MICR;
		
		return k.compareTo(p);
	}
	

}
