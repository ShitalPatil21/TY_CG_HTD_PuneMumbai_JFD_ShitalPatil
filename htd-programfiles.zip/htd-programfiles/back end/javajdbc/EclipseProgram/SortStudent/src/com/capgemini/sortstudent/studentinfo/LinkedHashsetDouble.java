package com.capgemini.sortstudent.studentinfo;

import java.util.HashSet;
import java.util.Iterator;

public class LinkedHashsetDouble {
public static void main(String[] args) {
		
		HashSet <Double>hs = new HashSet<Double>();
		hs.add(5.1);
		hs.add(7.2);
		hs.add(1.1);
		hs.add(4.3);
		
		System.out.println(".........using for each..........");
		for(Double r :hs)
		{
			System.out.println(r);
		}
		
		System.out.println("........using iterator...........");
		Iterator <Double>it = hs.iterator();
		while(it.hasNext())
		{
			Double r = it.next();
			System.out.println(r);
		}
	}
		

}
