package com.capgemini.sortstudent.studentinfo;

import java.util.TreeSet;
import java.util.Iterator;


public class TestTreeSetEmployee {

	public static void main(String[] args) {
		TreeSet <String>hs = new TreeSet <String>();
		
		
		hs.add("Aishwarya");
		hs.add("Abhishek");
		hs.add("Hrishikesh");
		hs.add("Ketaki");
		

		System.out.println(".........using TreeSet..........");
		Iterator <String> it = hs.iterator();
		while(it.hasNext())
		{
			String e = it.next();
			System.out.println(e);
			
			System.out.println("......................");
		}
		
		
		
		
		
	}

}
