package com.capgemini.sort.student.bank;


import java.util.Iterator;
import java.util.TreeSet;



public class TestBank {

	public static void main(String[] args) {
		
		ById comp=new ById();
		
		ByName compbyName = new ByName();
		
		ByMICR compmicr = new ByMICR();
//Hashset
		TreeSet <Bank>hs = new TreeSet <Bank>(compmicr);

//Bank Object
		Bank e1 = new Bank(11,"Aishwarya",1);
		Bank e2 = new Bank(2,"Hrishikesh",20202);
		Bank e3 = new Bank(33,"Ketaki",303);
		
//assign values
		hs.add(e1);
		hs.add(e2);
		hs.add(e3);
		
		System.out.println(".........using TreeSet..........");
		Iterator <Bank> it = hs.iterator();
		while(it.hasNext())
		{
			Bank e = it.next();
			System.out.println("Name = "+e.Pin);
			System.out.println("ID = "+e.Name);
			System.out.println("Salary = "+e.MICR);
			System.out.println("................................");
		}
		
		

	}

}
