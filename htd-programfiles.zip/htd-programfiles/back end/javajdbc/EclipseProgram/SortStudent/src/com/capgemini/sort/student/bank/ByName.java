package com.capgemini.sort.student.bank;

import java.util.Comparator;

public class ByName implements Comparator<Bank>{

	@Override
	public int compare(Bank o1, Bank o2) {
		return o1.Name.compareTo(o2.Name);
	}
	

}
