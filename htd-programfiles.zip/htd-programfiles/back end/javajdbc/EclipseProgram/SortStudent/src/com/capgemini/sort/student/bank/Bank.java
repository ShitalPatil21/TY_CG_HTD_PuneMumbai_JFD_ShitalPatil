package com.capgemini.sort.student.bank;

public class Bank {
//variable declare
		int Pin;
		String Name;
		long MICR;
		
//constructor
		public Bank(int pin, String name, long mICR) {
			super();
			Pin = pin;
			Name = name;
			MICR = mICR;
		}
		
		
}
