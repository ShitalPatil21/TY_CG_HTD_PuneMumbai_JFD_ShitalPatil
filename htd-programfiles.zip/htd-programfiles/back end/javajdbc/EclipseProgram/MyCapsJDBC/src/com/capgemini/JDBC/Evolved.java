package com.capgemini.JDBC;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class Evolved {

	public static void main(String[] args) {
		FileReader reader = null;
		Properties prop = null;
		ResultSet rs = null;
		Statement stmt = null;
		try {
			// load the driver
			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);
			Class.forName(prop.getProperty("driverClass"));
			System.out.println("driver loaded");

		} catch (Exception e) {
			e.printStackTrace();
		}

		try (Connection conn = DriverManager.getConnection
				(prop.getProperty("dburl"), prop.getProperty("user"),
						prop.getProperty("password")))
		{
			stmt = conn.createStatement();
			rs = stmt.executeQuery(prop.getProperty("query"));
			while (rs.next()) 
			{
				System.out.println("user Id : " + rs.getInt(1));
				System.out.println("user name : " + rs.getString("username"));
				System.out.println("Email : " + rs.getString(3));
				System.out.println("Password : " + rs.getString("password"));
				System.out.println("************************");
			}


		} catch (Exception e) {

		}

	}

}
