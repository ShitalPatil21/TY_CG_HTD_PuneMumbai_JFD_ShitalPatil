package com.capgemini.JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InsertFromUser {
	public static void main(String[] args) {
		Connection conn=null;
		Scanner sc=new Scanner(System.in);
		PreparedStatement pstmt=null;
		
		try {
			
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded...............");
			System.out.println("**********************");
			
			
			//get the connection
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			conn = DriverManager.getConnection(dbUrl);
			System.out.println("connection established.........");
			System.out.println("************************");
			
			//issue the query
			String query ="INSERT INTO user_info VALUES(?,?,?,?)";
			pstmt =conn.prepareStatement(query);
			
			
			
			Pattern pat2= Pattern.compile("\\d{1,5}");
			System.out.println("Enter the User ID");
			String id = sc.nextLine();
			Matcher mat2=pat2.matcher(id);
			if(mat2.matches() == true) {
			
			pstmt.setInt(1, Integer.parseInt(id));
			
			System.out.println("Enter the User Name");
			pstmt.setString(2, sc.nextLine());
			
			System.out.println("Enter the Email");
			pstmt.setString(3, sc.nextLine());
			
			System.out.println("Enter the Password");
			pstmt.setString(4, sc.nextLine());
			
			
			sc.close();
			
			int count=pstmt.executeUpdate();
			
			
			//process the result
			if(count>0)
			{
				System.out.println("dsta inserted........");
			}
			}
			else
			{
				System.out.println("enter ID upto 6 digit");
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			//System.out.println("Enter the User ID");
			//pstmt.setInt(1, Integer.parseInt(sc.nextLine()));
			
//			System.out.println("Enter the User Name");
//			pstmt.setString(2, sc.nextLine());
//			
//			System.out.println("Enter the Email");
//			pstmt.setString(3, sc.nextLine());
//			
//			System.out.println("Enter the Password");
//			pstmt.setString(4, sc.nextLine());
//			
//			
//			sc.close();
//			
//			int count=pstmt.executeUpdate();
//			
//			
//			//process the result
//			if(count>0)
//			{
//				System.out.println("dsta inserted........");
//			}
			
			
			
			
			
			
			
			
			
			
			
		
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		finally 
		{
			if(conn!=null)
			{
				try 
				{
					conn.close();
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
			if(pstmt!=null)
			{
				try {
				pstmt.close();
				}
				catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			
			
		}
	}


}
