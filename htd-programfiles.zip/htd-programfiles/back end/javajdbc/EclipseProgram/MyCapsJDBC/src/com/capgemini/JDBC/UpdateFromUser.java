package com.capgemini.JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UpdateFromUser {

	public static void main(String[] args) {

		Connection conn = null;
		Scanner sc = new Scanner(System.in);
		PreparedStatement pstmt = null;

		try {

			// load the Driver
			java.sql.Driver driver = new com.mysql.jdbc.Driver();
			DriverManager.registerDriver(driver);
			System.out.println("Driver loaded.....");
			System.out.println("*********************");

			// get the db connection via driver
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db";

			// input from user
			System.out.println("enter user ID");
			String user = sc.nextLine();
			System.out.println("enter user password");
			String password = sc.nextLine();
			
			
			// connection
			conn = DriverManager.getConnection(dbUrl, user, password);
			System.out.println("connection established.........");
			System.out.println("************************");

			// issue SQL query via connection
			String query = "UPDATE user_info SET email = ? WHERE userid = ? AND password = ?";
			pstmt =conn.prepareStatement(query);
			
			System.out.println("Enter the Email");
			pstmt.setString(1, sc.nextLine());
			
			System.out.println("Enter the User ID");
			pstmt.setInt(2, Integer.parseInt(sc.nextLine()));
			
			System.out.println("Enter the Password");
			pstmt.setString(3, sc.nextLine());
						
			
			
			

			sc.close();
			
			int count=pstmt.executeUpdate();
			
			
			//process the result
			if(count>0)
			{
				System.out.println("dsta inserted........");
			}
		

		} catch (Exception e) {

			e.printStackTrace();
		}

		finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
	}

}
