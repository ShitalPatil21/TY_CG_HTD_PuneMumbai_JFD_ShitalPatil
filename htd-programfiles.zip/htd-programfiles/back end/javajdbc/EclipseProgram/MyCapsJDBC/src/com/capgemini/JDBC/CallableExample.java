package com.capgemini.JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import java.sql.CallableStatement;

public class CallableExample 
{

	public static void main(String[] args)
	{

		Connection conn = null;
		CallableStatement cstmt = null;
		Scanner sc = new Scanner(System.in);
		ResultSet rs = null;

		try 
		{
			// load the driver
			Class.forName("com.mysql.jdbc.Driver");

			System.out.println("Driver loaded...............");
			System.out.println("**********************");

			// get connection
			String dburl = "jdbc:mysql://localhost:3306/capg_db";
			
			//user name and password of system
			System.out.println("Enter the username of system");
			String user = sc.nextLine();
			System.out.println("Enter the password of system");
			String password = sc.nextLine();
			sc.close();
			
			
			conn = DriverManager.getConnection(dburl, user, password);
			System.out.println("connection established......");
			System.out.println("**********************");

			// issue sql query
			String query = "call GetAllInfo()";
			cstmt = conn.prepareCall(query);
			boolean b = cstmt.execute();
			
			if (b) 
			{
				rs = cstmt.getResultSet();
				while (rs.next()) 
				{
					System.out.println("userid :" + rs.getInt(1));
					System.out.println("username :" + rs.getString(2));
					System.out.println("email :" + rs.getString(3));
					System.out.println("password :" + rs.getString(4));
					System.out.println("***************************");
				}
			} 
			else 
			{
				int i = cstmt.getUpdateCount();
				if (i > 0) 
				{
					System.out.println("operation successfulll........");
				}
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
		} 
		finally 
		{
			if (conn != null)
			{
				try 
				{
					conn.close();
				} catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
			if (cstmt != null) 
			{
				try 
				{
					cstmt.close();
				} catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
			if (rs != null) 
			{
				try 
				{
					rs.close();
				} catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}

		}
	}

}
