package com.capgemini.JDBC;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;



public class JDBCRetrival {

	public static void main(String[] args) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		Scanner sc=new Scanner(System.in);
		ResultSet rs = null;
		//int x = sc.nextInt();
		
		try {
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver is loaded......");
			System.out.println("***************");
			
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			conn = DriverManager.getConnection(dbUrl);
			System.out.println("connection established.........");
			System.out.println("************************");
			
			//issue the sql query
			String query = "SELECT * FROM user_info where userid = ?";
			pstmt =conn.prepareStatement(query);
			System.out.println("Enter the User ID");
			pstmt.setInt(1, sc.nextInt());
			sc.close();
			rs = pstmt.executeQuery();
			
			//process the reuslt
			if(rs.next())
			{
				System.out.println("User ID : "+rs.getInt(1));
				System.out.println("user name : "+rs.getString(2));
				System.out.println("Email : "+rs.getString(3));
				System.out.println("password : "+rs.getString(4));
			}
			else
			{
				System.out.println("user not available");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		finally
		{
			if(conn!=null)
			{
				try {
				conn.close();
				}
				catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(pstmt!=null)
			{
				try {
				pstmt.close();
				}
				catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			if(rs!=null)
			{
				try {
				rs.close();
				}
				catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
			
		}

		
	}

}
