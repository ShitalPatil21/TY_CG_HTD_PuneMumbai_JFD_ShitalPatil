package com.capgemini.JDBC;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
//import java.util.Scanner;

public class JDBCretrivalAll {

	public static void main(String[] args) {

		Connection conn = null;
		FileReader reader = null;
		Properties prop = null;
		//PreparedStatement pstmt = null;
		//Scanner sc = new Scanner(System.in);
		ResultSet rs = null;
		Statement stmt = null;

		try 
		{
			reader = new FileReader("db.properties");
			prop = new Properties();
			prop.load(reader);
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}

		try 
		{
			String dburl = prop.getProperty("dburl");
			conn = DriverManager.getConnection(dburl, prop.getProperty("user"), prop.getProperty("password"));
			System.out.println("-----connection establish------");
			System.out.println("...............................");

			String query = "SELECT * FROM user_info";

			/*
			 * pstmt =conn.prepareStatement(query); System.out.println("Enter the User ID");
			 * pstmt.setInt(1, sc.nextInt()); sc.close(); rs = pstmt.executeQuery();
			 * 
			 * if(rs.next()) { System.out.println("User ID : "+rs.getInt(1));
			 * System.out.println("user name : "+rs.getString(2));
			 * System.out.println("Email : "+rs.getString(3));
			 * System.out.println("password : "+rs.getString(4)); } else {
			 * System.out.println("user not available"); }
			 */

			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);

			while (rs.next()) 
			{
				System.out.println("user Id : " + rs.getInt(1));
				System.out.println("user name : " + rs.getString("username"));
				System.out.println("Email : " + rs.getString(3));
				System.out.println("Password : " + rs.getString("password"));
				System.out.println("************************");
			}

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}

	}

}
