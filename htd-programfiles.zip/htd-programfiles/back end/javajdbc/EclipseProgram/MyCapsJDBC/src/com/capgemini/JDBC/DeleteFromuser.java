package com.capgemini.JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class DeleteFromuser {
	public static void main(String[] args) {
		PreparedStatement pstmt=null;
		Connection conn=null;
		Scanner sc=new Scanner(System.in);
		try {
			
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded...............");
			System.out.println("**********************");
			
			
			//get the connection
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			conn = DriverManager.getConnection(dbUrl);
			System.out.println("connection established.........");
			System.out.println("************************");
			
			//issue the query
			String query ="DELETE FROM user_info WHERE userid = ?";
			pstmt =conn.prepareStatement(query);
			
			System.out.println("Enter the User ID");
			pstmt.setInt(1, Integer.parseInt(sc.nextLine()));
			sc.close();
			
			int count=pstmt.executeUpdate();
	
			//process the result
			if(count>0)
			{
				System.out.println("data deleted........");
			}
		
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		finally 
		{
			if(conn!=null)
			{
				try 
				{
					conn.close();
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}

	}

}
