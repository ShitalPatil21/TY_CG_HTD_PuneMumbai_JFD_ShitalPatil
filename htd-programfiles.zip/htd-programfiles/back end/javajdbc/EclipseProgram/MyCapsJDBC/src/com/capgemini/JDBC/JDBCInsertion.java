package com.capgemini.JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class JDBCInsertion {
	public static void main(String[] args) {
		Connection conn=null;
		Statement stmt =null;
		
		try {
			
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded...............");
			System.out.println("**********************");
			
			
			//get the connection
			String dbUrl = "jdbc:mysql://localhost:3306/capg_db?user=root&password=root";
			conn = DriverManager.getConnection(dbUrl);
			System.out.println("connection established.........");
			System.out.println("************************");
			
			//issue the query
			String query ="INSERT INTO user_info VALUES(8,'vaishali','vaishali@gmail.com','vaishali')";
			stmt = conn.createStatement();
			int count=stmt.executeUpdate(query);
	
			//process the result
			if(count>0)
			{
				System.out.println("dsta inserted........");
			}
		
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
		finally 
		{
			if(conn!=null)
			{
				try 
				{
					conn.close();
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
	}

}
