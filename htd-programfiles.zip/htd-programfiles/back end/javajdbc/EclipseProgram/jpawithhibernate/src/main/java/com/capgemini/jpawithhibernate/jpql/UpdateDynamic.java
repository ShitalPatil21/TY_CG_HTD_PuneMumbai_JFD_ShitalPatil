package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class UpdateDynamic {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Movie");
		EntityManager em = emf.createEntityManager();

		String jpql = "update Movie set Name=:nm where ID=:mid";
		EntityTransaction entityTransaction = em.getTransaction();

		entityTransaction.begin();
		Query que = em.createQuery(jpql);
		que.setParameter("nm", "Dhoom");
		que.setParameter("mid", 1);
		int result = que.executeUpdate();
		entityTransaction.commit();

		System.out.println("result" + result);
		System.out.println("record updated");

		em.close();
	}

}
