package com.capgemini.jpawithhibernate.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class onetomanytest {

	public static void main(String[] args) {
		
		PencilBox pencilebox = new PencilBox();
		pencilebox.setBoxid(3);
		pencilebox.setBoxname("camlin");
		
		Pencil pencil = new Pencil();
		pencil.setPid(11);
		pencil.setColor("black");
		pencil.setPencilbox(pencilebox);
		
		Pencil pencil1 = new Pencil();
		pencil1.setPid(23);
		pencil1.setColor("red");
		pencil1.setPencilbox(pencilebox);
		
		
		
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		try {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Movie");
			entityManager = entityManagerFactory.createEntityManager();
			entityTransaction = entityManager.getTransaction();

			entityTransaction.begin();
			
			entityManager.persist(pencil);
			entityManager.persist(pencil1);
			System.out.println("Record Inserted");
			entityTransaction.commit();
		}
		catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

}
