package com.capgemini.jpawithhibernate.jpql;

import java.util.List;
import java.util.stream.Stream;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.jpawithhibernate.dto.Movie;

public class Update {

	public static void main(String[] args) {
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Movie");
		EntityManager em = emf.createEntityManager();
		
		String jpql = "update Movie set Name='golmal' where ID=4";
		EntityTransaction entityTransaction = em.getTransaction();
			
			entityTransaction.begin();
		Query que = em.createQuery(jpql);
		int result =que.executeUpdate();
		entityTransaction.commit();
		
		System.out.println("result"+result);
		System.out.println("record updated");
		
		em.close();
	}

}
