package com.capgemini.jpawithhibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.dto.Movie;

public class Reattach {

	public static void main(String[] args) {
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;

		try {
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Movie");
			entityManager = entityManagerFactory.createEntityManager();

			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			
			Movie data = entityManager.find(Movie.class, 1);
			System.out.println(data.getID());
			System.out.println(entityManager.contains(data));
			
			entityManager.detach(data);//accept only one input 
			System.out.println(entityManager.contains(data));
			
			Movie movie1 = entityManager.merge(data);
			movie1.setMName("Annabelle");
			
			//entityManager.clear();//clear all data from persistance object
			
			System.out.println("Record Updated,l");
			entityTransaction.commit();
		} // end of try

		catch (Exception e) {
			entityTransaction.rollback();
			e.printStackTrace();

		} // end of catch

		entityManager.close();

	}// end of main

}// end of class
