package com.capgemini.jpawithhibernate;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.dto.Movie;

public class InsertDemo {

	public static void main(String[] args) {
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		
		Scanner sc = new Scanner(System.in);
		
		Movie movie=new Movie();
		
		System.out.println("Enter ID");
		movie.setID(Integer.parseInt(sc.nextLine()));
		System.out.println("Enter Name");
		movie.setMName(sc.nextLine());
		System.out.println("Enter rating");
		movie.setRating(sc.nextLine());
		sc.close();
			 
		try 
		{
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Movie");
			 entityManager = entityManagerFactory.createEntityManager();
			 entityTransaction = entityManager.getTransaction();
			
			entityTransaction.begin();
			entityManager.persist(movie);
			
			System.out.println("Record Saved");
			entityTransaction.commit();
		}//end of try 
		
		catch (Exception e) 
		{
			entityTransaction.rollback();
			e.printStackTrace();
			
		}//end of catch
		
		entityManager.close();
	}//end of main

}//end of class
