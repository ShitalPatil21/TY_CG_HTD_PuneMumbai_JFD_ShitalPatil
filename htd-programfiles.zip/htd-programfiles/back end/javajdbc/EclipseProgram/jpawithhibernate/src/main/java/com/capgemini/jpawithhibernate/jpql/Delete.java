package com.capgemini.jpawithhibernate.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Delete {

	public static void main(String[] args) {
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Movie");
		 entityManager = entityManagerFactory.createEntityManager();
		 String jpql = "delete from Movie where ID=5";
		 entityTransaction = entityManager.getTransaction();
		 entityTransaction.begin();
		 Query que = entityManager.createQuery(jpql);
			int result =que.executeUpdate();
		
			entityTransaction.commit();
			System.out.println("result"+result);
			System.out.println("record deleted");
			entityManager.close();

	}

}
