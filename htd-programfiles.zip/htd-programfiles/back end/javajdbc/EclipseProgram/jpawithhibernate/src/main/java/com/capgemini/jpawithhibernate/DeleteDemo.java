package com.capgemini.jpawithhibernate;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.dto.Movie;

public class DeleteDemo {

	public static void main(String[] args) {
		
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		
		
		
		
		try 
		{
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Movie");
			 entityManager = entityManagerFactory.createEntityManager();
			 entityTransaction = entityManager.getTransaction();
			
			entityTransaction.begin();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter ID which you want to delte");
			
			Movie data = entityManager.find(Movie.class, sc.nextInt());
			entityManager.remove(data);
			
			System.out.println("Record Delete");
			entityTransaction.commit();
			
			sc.close();
		}//end of try 
		
		catch (Exception e) 
		{
			entityTransaction.rollback();
			e.printStackTrace();
			
		}//end of catch
		
		entityManager.close();

		
	}//end of main

}//end of class
