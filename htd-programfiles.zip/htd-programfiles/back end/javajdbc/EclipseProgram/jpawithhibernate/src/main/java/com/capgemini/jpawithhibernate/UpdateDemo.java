package com.capgemini.jpawithhibernate;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.jpawithhibernate.dto.Movie;

public class UpdateDemo {

	public static void main(String[] args) {
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		
		try 
		{
			EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("Movie");
			 entityManager = entityManagerFactory.createEntityManager();
			 entityTransaction = entityManager.getTransaction();
			
			entityTransaction.begin();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter ID where you want to update data");
			Movie data = entityManager.find(Movie.class, Integer.parseInt(sc.nextLine()));
			
			System.out.println("enter the number where you want to update");
			System.out.println("1. update name");
			System.out.println("2.update rating");
			int a=Integer.parseInt(sc.nextLine());
			if(a==1) {
				System.out.println("enter the name");
			data.setMName(sc.nextLine());
			}
			else if(a==2)
			{
				System.out.println("enter the rating");
				data.setRating(sc.nextLine());
				
			}
			else
			{
				System.out.println("select the option");
			}
			System.out.println("Record Updated");
			entityTransaction.commit();
			
			sc.close();
		}//end of try 
		
		catch (Exception e) 
		{
			entityTransaction.rollback();
			e.printStackTrace();
			
		}//end of catch
		
		entityManager.close();


		
	}//end of main

}//end of class
