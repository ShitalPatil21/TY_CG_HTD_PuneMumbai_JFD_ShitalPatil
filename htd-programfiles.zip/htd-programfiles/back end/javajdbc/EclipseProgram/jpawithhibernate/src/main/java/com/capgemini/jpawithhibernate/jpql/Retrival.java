package com.capgemini.jpawithhibernate.jpql;

import java.util.List;
import java.util.ListIterator;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.jpawithhibernate.dto.Movie;

public class Retrival {
	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("Movie");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
				
		String jpql= "from Movie";
		Query query = entityManager.createQuery(jpql);
		List<Movie>list = query.getResultList();
		
		for(Movie m :list) {
		System.out.println(m.getID());
		System.out.println(m.getRating());
		System.out.println(m.getMName());
		}
		//Movie data=entityManager.find(Movie.class, 1);
		//System.out.println("ID     = "+data.getID());
		//System.out.println("Name   = "+data.getMName());
		//System.out.println("Rating ="+data.getRating());
		
		
	}//end of main


}
