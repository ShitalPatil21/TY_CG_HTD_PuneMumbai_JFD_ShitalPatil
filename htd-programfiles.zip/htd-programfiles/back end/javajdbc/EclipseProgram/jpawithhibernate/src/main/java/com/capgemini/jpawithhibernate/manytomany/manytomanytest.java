package com.capgemini.jpawithhibernate.manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class manytomanytest {

	public static void main(String[] args) {

		
		
		Course crs = new Course();
		crs.setCid(101);
		crs.setCname("Java");
		
		Course crs1 = new Course();
		crs1.setCid(102);
		crs1.setCname("SQL");
		
		ArrayList<Course> alist = new ArrayList<Course>();
		alist.add(crs);
		alist.add(crs1);
		
		Student stud = new Student();
		stud.setSid(1);
		stud.setSname("Aishwarya");
		stud.setCourse(alist);
	
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("Movie");
			EntityManager em = emf.createEntityManager();
			EntityTransaction et = em.getTransaction();
			
			et.begin();
			em.persist(stud);
			System.out.println("record saved");
			et.commit();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
