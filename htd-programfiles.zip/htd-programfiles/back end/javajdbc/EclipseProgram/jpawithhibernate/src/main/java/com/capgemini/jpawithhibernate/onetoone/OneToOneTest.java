package com.capgemini.jpawithhibernate.onetoone;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class OneToOneTest {

	public static void main(String[] args) {

		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		Scanner sc=new Scanner(System.in);
		
		Person person = new Person();
		System.out.println("enter the person id");
		person.setPid(Integer.parseInt(sc.nextLine()));
		System.out.println("enter the person name");
		person.setName(sc.nextLine());
		System.out.println("Data is...................");
		System.out.println("person ID");
		System.out.println(person.getPid());
		System.out.println("person name");
		System.out.println(person.getName());

		VoterCard vc = new VoterCard();
		System.out.println("enter the address votercard");
		vc.setAddress(sc.nextLine());
		System.out.println("enter the voter Id");
		vc.setVid(Integer.parseInt(sc.nextLine()));

		person.setVotercard(vc);
		System.out.println("votercard id");
		System.out.println(person.getVotercard().getVid());
		System.out.println("votercard address");
		System.out.println(person.getVotercard().getAddress());
		
		
		try {
			EntityManagerFactory entityManagerFactory1 = Persistence.createEntityManagerFactory("Movie");
			 entityManager = entityManagerFactory1.createEntityManager();
			 entityTransaction = entityManager.getTransaction();
			
			entityTransaction.begin();
			entityManager.persist(person);
			
			System.out.println("Record Saved");
			entityTransaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
		entityManager.close();
	}//end of main

}//end of class	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		try {
//			System.out.println("................");
//			entityManagerFactory = Persistence.createEntityManagerFactory("Movie");
//			System.out.println("............");
//			 entityManager = entityManagerFactory.createEntityManager();
//			entityTransaction = entityManager.getTransaction();
//			
//			entityTransaction.begin();
//			
//			
//			System.out.println("enter the Person  ID to find that person");
//			 person= entityManager.find(Person.class, Integer.parseInt(sc.nextLine()));
//			
//			 entityManager.persist(person);
//			 
//			System.out.println("data..........................");
//			System.out.println(person.getPid());
//			System.out.println(person.getName());
//			System.out.println(person.getVotercard().getVid());
//			System.out.println(person.getVotercard().getAddress());
//			
////			System.out.println("enter the voter id");
////			VoterCard vc2 = entityManager.find(VoterCard.class, Integer.parseInt(sc.nextLine()));
////			entityManager.persist(vc2);
////			System.out.println("data..........................");
////			System.out.println(vc2.getVid());
////			System.out.println(vc2.getAddress());
////			System.out.println(vc2.getPerson().getPid());
////			System.out.println(vc2.getPerson().getName());
//
//			
//			System.out.println("end...............");
//
//			entityTransaction.commit();
//		} // end of try
//
//		catch (Exception e) {
//			entityTransaction.rollback();
//			e.printStackTrace();
//
//		} // end of catch

//	entityManager.close();


