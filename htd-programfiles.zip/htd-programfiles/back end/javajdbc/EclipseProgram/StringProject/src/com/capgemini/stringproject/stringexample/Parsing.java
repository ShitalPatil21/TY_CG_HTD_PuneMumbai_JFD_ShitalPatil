package com.capgemini.stringproject.stringexample;

public class Parsing {
	public static void main(String [] args)
	{
		String k="90";
		
		String w="10";
		
		System.out.println(k+w);
		
		int i=Integer.parseInt(k);
		int j=Integer.parseInt(w);
		
		System.out.println(i+j);
	}

}
