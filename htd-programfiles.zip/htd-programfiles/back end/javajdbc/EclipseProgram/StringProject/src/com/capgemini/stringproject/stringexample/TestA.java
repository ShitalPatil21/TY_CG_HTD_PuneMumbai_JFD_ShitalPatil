package com.capgemini.stringproject.stringexample;

public class TestA {
	public static void main(String [] args)
	{
		String a="Aishu";
		String b="Hrishi";
		 a="Ketaki";
		 System.out.println("a is = "+a);
		 System.out.println("b is = "+b);
	}

}
