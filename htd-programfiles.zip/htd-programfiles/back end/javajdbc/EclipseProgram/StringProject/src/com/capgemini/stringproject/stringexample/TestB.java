package com.capgemini.stringproject.stringexample;

public class TestB {
	public static void main(String [] args)
	{
		String a="Aishu";
		String b="Hrishi";
		String c="Aishu";
		
		 System.out.println("a is = "+a);
		 System.out.println("b is = "+b);
		 System.out.println("b is = "+c);
		
	}

}
