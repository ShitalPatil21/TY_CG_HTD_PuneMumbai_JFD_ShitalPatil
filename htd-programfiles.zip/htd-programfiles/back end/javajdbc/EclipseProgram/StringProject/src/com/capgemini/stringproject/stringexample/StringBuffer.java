package com.capgemini.stringproject.stringexample;

public class StringBuffer {

	public static void main(String [] args)
	{
		StringBuilder sb= new StringBuilder();
		sb.append("Priya");
		System.out.println(sb);
	}
}
