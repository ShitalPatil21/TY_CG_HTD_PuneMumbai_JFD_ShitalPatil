package com.capgemini.stringproject.stringexample;

public interface Ex {

}
