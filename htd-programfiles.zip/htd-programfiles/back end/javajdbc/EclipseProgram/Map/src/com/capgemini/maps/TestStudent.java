package com.capgemini.maps;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class TestStudent {
	public static void main(String[] args) {
		
		
		
		Student s1 = new Student("aishu",1,40.45);
		Student s2 = new Student("hrishi",2,80.45);
		Student s3 = new Student("ketaki",3,60.45);
		Student s4 = new Student("amruta",4,75.45);
		Student s5 = new Student("abhi",5,95.45);
		Student s6 = new Student("atharva",6,76.45);
		Student s7 = new Student("aditi",7,55.45);
		Student s8 = new Student("nikita",8,68.45);
		Student s9 = new Student("komal",9,99.45);
		
		ArrayList<Student> al1 = new ArrayList<Student>();
		al1.add(s1);
		al1.add(s2);
		al1.add(s3);
		
		ArrayList<Student> al2 = new ArrayList<Student>();
		al2.add(s4);
		al2.add(s5);
		al2.add(s6);
		
		ArrayList<Student> al3 = new ArrayList<Student>();
		al3.add(s7);
		al3.add(s8);
		al3.add(s9);
		
		LinkedHashMap<String, ArrayList<Student>> hm = 
				new LinkedHashMap<String,ArrayList<Student> >();
		hm.put("first",al1);
		hm.put("second",al2);
		hm.put("third",al3);
		
		ArrayList<Student> al= hm.get("third");
		Iterator<Student> it = al.iterator();
		while(it.hasNext())
		{
			Student s = it.next();
			System.out.println("Name = "+s.Name);
			System.out.println("Name = "+s.ID);
			System.out.println("Name = "+s.Percentage);
			System.out.println("..............................");
		}
		
	
	}
}
