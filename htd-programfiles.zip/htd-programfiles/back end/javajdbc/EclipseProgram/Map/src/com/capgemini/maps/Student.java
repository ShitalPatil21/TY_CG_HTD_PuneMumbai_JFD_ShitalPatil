package com.capgemini.maps;

public class Student {
	String Name;
	int ID;
	double Percentage;
	
	
	public Student(String name, int iD, double percentage) {
		super();
		Name = name;
		ID = iD;
		Percentage = percentage;
	}
	
	

}
