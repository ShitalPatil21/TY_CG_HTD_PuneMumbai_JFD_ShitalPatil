package com.capgemini.maps;

import java.util.LinkedHashMap;

public class LinkedHashMap3 {
	public static void main(String[] args) {

		LinkedHashMap<String, Integer> hm = new LinkedHashMap<String, Integer>();
		hm.put("Ondhu", 1);
		hm.put("Indhu", 5);
		hm.put("Hathu", 10);
		hm.put("Eredu", 2);

	}

}
