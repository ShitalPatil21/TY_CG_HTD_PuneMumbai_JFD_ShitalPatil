package com.capgemini.springboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringBootController {
   
	@GetMapping(path="/",produces = "text/plain")
	public String welcomeMessage() {
		return "Welcome to SpringBoot";
	}//end of springbootCOntroller
	
}//end of of class
