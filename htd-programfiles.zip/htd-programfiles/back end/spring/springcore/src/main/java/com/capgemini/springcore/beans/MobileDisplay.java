package com.capgemini.springcore.beans;

public class MobileDisplay {
	
	private int displaySize;
	private int resolution;
	public int getDisplaySize() {
		return displaySize;
	}
	public void setDisplaySize(int displaySize) {
		this.displaySize = displaySize;
	}
	public int getResolution() {
		return resolution;
	}
	public void setResolution(int resolution) {
		this.resolution = resolution;
	}
	

}
