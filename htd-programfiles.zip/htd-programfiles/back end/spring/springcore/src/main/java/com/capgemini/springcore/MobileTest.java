package com.capgemini.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.Mobile;



public class MobileTest {

	public static void main(String[] args) {

		ApplicationContext context=new ClassPathXmlApplicationContext("mobileconfig.xml");
        Mobile mobile=context.getBean("Mobile",Mobile.class) ;
        System.out.println("By Type");
        System.out.println("Mobile brand "+mobile.getBrandName());
        System.out.println("Mobile Model "+mobile.getModelName());
        System.out.println("Mobile Price "+mobile.getPrice());
        
        System.out.println("Mobile display size"+mobile.getMobileDisplay().getDisplaySize());
		System.out.println("mobile Resolution"+mobile.getMobileDisplay().getResolution());
		System.out.println("*****************************************************");
		 Mobile mobile1=context.getBean("mobile2",Mobile.class) ;
		 System.out.println("using By Name");
		 System.out.println("Mobile brand "+mobile1.getBrandName());
	        System.out.println("Mobile Model "+mobile1.getModelName());
	        System.out.println("Mobile Price "+mobile1.getPrice());
	        
	        System.out.println("Mobile display size"+mobile1.getMobileDisplay().getDisplaySize());
			System.out.println("mobile Resolution"+mobile1.getMobileDisplay().getResolution());
			System.out.println("*****************************************************");
			 Mobile mobile2=context.getBean("mobile3",Mobile.class) ;	
			 
			 System.out.println("using By ref");
			 System.out.println("Mobile brand "+mobile2.getBrandName());
		        System.out.println("Mobile Model "+mobile2.getModelName());
		        System.out.println("Mobile Price "+mobile2.getPrice());
		        
		        System.out.println("Mobile display size"+mobile2.getMobileDisplay().getDisplaySize());
				System.out.println("mobile Resolution"+mobile2.getMobileDisplay().getResolution());
			
			
	}

}
