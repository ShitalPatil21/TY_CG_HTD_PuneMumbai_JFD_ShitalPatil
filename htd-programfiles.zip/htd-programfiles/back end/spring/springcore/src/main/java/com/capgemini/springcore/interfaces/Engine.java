package com.capgemini.springcore.interfaces;

public interface Engine {

	public int getCC();
	public String getType();
}
