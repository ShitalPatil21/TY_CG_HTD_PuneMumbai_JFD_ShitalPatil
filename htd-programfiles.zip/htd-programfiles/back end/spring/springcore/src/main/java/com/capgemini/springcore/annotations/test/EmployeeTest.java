package com.capgemini.springcore.annotations.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.capgemini.springcore.annotations.beans.EmployeeBean;
import com.capgemini.springcore.annotations.config.DepartmentConfig;
import com.capgemini.springcore.annotations.config.EmployeeConfig;

public class EmployeeTest {

	public static void main(String[] args) {


		//ApplicationContext context=new AnnotationConfigApplicationContext(EmployeeConfig.class,DepartmentConfig.class);

		ApplicationContext context=new AnnotationConfigApplicationContext(EmployeeConfig.class);
		EmployeeBean employeeBean=context.getBean(EmployeeBean.class);
		System.out.println("***************************");
		System.out.println("Emp Id:"+employeeBean.getEmpId());
		System.out.println("Emp Name:"+employeeBean.getEmpName());
		
		//((AbstractApplicationContext)context).close();
		System.out.println("***************************");
			System.out.println("Department Id :"+employeeBean.getDepartmentBean().getDeptId());
		    System.out.println("Department name is:"+employeeBean.getDepartmentBean().getDeptName());
		
		    System.out.println("***************************");
		((AbstractApplicationContext)context).registerShutdownHook();

	}

}
