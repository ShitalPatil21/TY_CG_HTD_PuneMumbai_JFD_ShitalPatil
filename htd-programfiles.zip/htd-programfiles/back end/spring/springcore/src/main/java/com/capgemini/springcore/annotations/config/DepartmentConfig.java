package com.capgemini.springcore.annotations.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.capgemini.springcore.annotations.beans.DepartmentBean;

@Configuration
public class DepartmentConfig {

	@Bean(name = "dev")
	public DepartmentBean getDevBean() {
		DepartmentBean bean = new DepartmentBean();
		bean.setDeptId(101);
		bean.setDeptName("Dev");
		return bean;
	}

	@Bean(name = "hr")
	public DepartmentBean getHrBean() {
		DepartmentBean bean = new DepartmentBean();
		bean.setDeptId(102);
		bean.setDeptName("HR");
		return bean;
	}

	@Bean(name = "testing")
	// @Primary
	public DepartmentBean getTestingBean() {
		DepartmentBean bean = new DepartmentBean();
		bean.setDeptId(103);
		bean.setDeptName("Testing");
		return bean;
	}

}
