package com.capgemini.springcore.annotations.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.springcore.beans.Medicine;

public class MedicineTest {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("medicineConfig.xml");
		Medicine medicine = context.getBean("medicine", Medicine.class);

		/*System.out.println("Medicine Name is :" + medicine.getName());
		System.out.println("Medicine Price is: " + medicine.getPrice());
		System.out.println("Medicine Type is :" + medicine.getType());
		System.out.println("Medicine drug list :" + medicine.getDrugs());*/
		System.out.println("Medicine Name is :" + medicine.getName());
		System.out.println("Medicine Price is: " + medicine.getPrice());
		System.out.println("Medicine Type is :" + medicine.getType());
		System.out.println("Medicine drug set :" + medicine.getDrugsSet());
	}

}
