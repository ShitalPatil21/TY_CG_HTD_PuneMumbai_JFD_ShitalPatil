package com.capgemini.springcore.beans;

import com.capgemini.springcore.interfaces.Engine;

public class Jagaur implements Engine{

	@Override
	public int getCC() {
	
		return 2900;
	}

	@Override
	public String getType() {


		return "2-Stroke petrol";
	}

}
