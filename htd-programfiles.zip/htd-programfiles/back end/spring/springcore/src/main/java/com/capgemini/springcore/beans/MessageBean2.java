package com.capgemini.springcore.beans;



public class MessageBean2 {
	public MessageBean2() {

   System.out.println("Instatiation");
	}
	
	private  String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
	public void init() {
		System.out.println("Its init Phase");
		
	}
	public void destroy() {
		System.out.println("Its Destroy Phase ");
	}
	

}//ENd of the class
