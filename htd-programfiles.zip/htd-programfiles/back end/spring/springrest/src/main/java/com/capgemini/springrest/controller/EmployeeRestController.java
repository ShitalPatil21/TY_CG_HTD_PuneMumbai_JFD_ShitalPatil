package com.capgemini.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.springrest.beans.EmployeeInfoBean;
import com.capgemini.springrest.beans.EmployeeResponse;
import com.capgemini.springrest.service.EmmployeeService;

//@Controller
@RestController
public class EmployeeRestController {
	@Autowired
	private EmmployeeService service;
	@GetMapping(path="/getEmployee",
			produces= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
	//@ResponseBody
	public EmployeeResponse getEmployee(int empId) {
		
		EmployeeInfoBean employeeInfoBean=service.getEmployee(empId);
		EmployeeResponse response=new  EmployeeResponse();
		if (employeeInfoBean !=null) {
			response.setStatuscode(401);
			response.setMessage("Sucess");
			response.setDescription("Employee Record found");
			response.setEmployeeInfoBean(employeeInfoBean);
			
		}
		else {
			response.setStatuscode(801);
			response.setMessage("Failed");
			response.setDescription("Employee Id"+empId+ "Record not found");
			
		}
		return response;
	}//end of getALlEmployee

	@PutMapping(path="/addEmployee",
			consumes= {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE},
			produces=MediaType.APPLICATION_JSON_VALUE)

	//@ResponseBody
	public EmployeeResponse addEmployee(@RequestBody EmployeeInfoBean employeeInfoBean) {
		boolean isAdded =service.addEmployee(employeeInfoBean);
		EmployeeResponse response=new EmployeeResponse();
		if(isAdded) {
			response.setStatuscode(201);
			response.setMessage("success");
			response.setDescription("Employee Added Suceesfully");
		}
		else {
			response.setStatuscode(401);
			response.setMessage("failed");
			response.setDescription("Unable to add employee");
		}
		return response;
	}//end of add employee
	
	@DeleteMapping(path="/deleteEmployee",
			produces= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public EmployeeResponse deleteEmployee(int empId) {
		boolean isDelete= service.deleteEmployee(empId);
		EmployeeResponse response=new EmployeeResponse();
		if(isDelete) {
			response.setStatuscode(201);
			response.setMessage("sucess");
			response.setDescription("Employee deleted Suceesfully");
		}
		else {
			response.setStatuscode(401);
			response.setMessage("failed");
			response.setDescription("Unable to delete employee");
		}
		return response;
	}//end of delete
	
	 
	
	@GetMapping(path="/getAll",
			produces= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public EmployeeResponse getAllEmployee() {
		List<EmployeeInfoBean> employeeList=service.getAllEmployees();
		EmployeeResponse response=new EmployeeResponse();
		if(employeeList !=null && !employeeList.isEmpty()) {
			response.setStatuscode(201);
			response.setMessage("sucess");
			response.setDescription("Employee Record Found");
			response.setEmployeeList(employeeList);
			
		}
		else {
			response.setStatuscode(401);
			response.setMessage("failed");
			response.setDescription("Unable to found employee");
		}
		return response;
	}//end of get all Employee
	
}//End of controller
