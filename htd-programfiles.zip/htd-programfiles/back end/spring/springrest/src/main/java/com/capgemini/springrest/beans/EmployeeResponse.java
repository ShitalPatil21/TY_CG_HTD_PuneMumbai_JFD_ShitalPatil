package com.capgemini.springrest.beans;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class EmployeeResponse {
    private int statuscode;
    private String message;
    private String description;
    private EmployeeInfoBean employeeInfoBean;
    private List<EmployeeInfoBean> employeeList;
	public EmployeeInfoBean getEmployeeInfoBean() {
		return employeeInfoBean;
	}
	public void setEmployeeInfoBean(EmployeeInfoBean employeeInfoBean) {
		this.employeeInfoBean = employeeInfoBean;
	}
	public int getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}
	public List<EmployeeInfoBean> getEmployeeList() {
		return employeeList;
	}
	public void setEmployeeList(List<EmployeeInfoBean> employeeList) {
		this.employeeList = employeeList;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
    
    //Getter and setters
    
	
}
